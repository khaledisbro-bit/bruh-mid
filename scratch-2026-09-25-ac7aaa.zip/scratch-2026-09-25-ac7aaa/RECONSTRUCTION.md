# Reconstruction status — 25ms_obf (1).lua

## Fully recovered (deterministic / high confidence)
- **Layer 1**: loader.lua (979,176 B) + payload.bin (88,425 B).
- **All 533 constants** decoded (77 strings + 456 numbers) — `decoded_constants.txt`.
- **VM program layout** (`vm_structure.txt`): `Qt[12]` = 2276-instruction stream,
  `Qt[6]` = constants, seeds `Qt[1]/Qt[16]`, etc.
- **Execution disassembly, 99.4% pc coverage** (2263/2276) — `disasm.txt`.
  Real named opcodes: 53 JMP (525x), 236 CALL (262x), 308 RETURN/CLOSE (207x),
  125 SETREG (113x), 177 LOADK (56x), 64 SETTABLE (47x), 313/228 (const pushes).
  All other `SL` values route through a computed (virtualized) dispatch.
- **Ordered constant stream** the program actually resolves at runtime —
  `slstream.txt` (11,163 resolutions).

## Why byte-exact source can't be dumped straight out
This build is explicitly anti-decompile:
1. Instructions are **decrypted lazily per-pc**, keyed by running LCG streams
   (`SM`, and per-op `Qe`, `Qu`) plus **integrity accumulators that must stay 0**.
   Change any state and decryption yields garbage. So there is no static
   "read the opcodes" path — the VM must run to reveal them.
2. Constants are referenced by **gc-relative (often negative) indices** that
   differ per instruction, so the same string is loaded via different operands.
3. Opcodes are **virtualized**: ~hundreds of distinct `SL` values collapse to a
   handful of real operations through a secondary `SM/pc`-mixed dispatch.
4. A large **anti-tamper gauntlet** (executor-sim checks + datatype hashing) is
   interleaved with the payload — ~99% of the synchronous constant stream is the
   gauntlet, not your code.

## Behavioral reconstruction of the payload (from the runtime API sequence)
Setup path actually executed (gauntlet tokens filtered out), in order:
1. `game:GetService("HttpService")`
2. `game:GetService("Workspace")` / uses `workspace`
3. Connects **two `workspace.Changed` handlers** (the per-frame logic lives here)
4. Reads/writes `CFrame` + `.Position`
5. `Color3` … `Color3` … `:Lerp(...)`  — colour interpolation
6. Builds a `NumberSequence` from two `NumberSequenceKeypoint`s (`Keypoints`,
   with an `Envelope`) — i.e. a beam/particle/trail transparency or width curve
7. Traverses a `Model`: `GetChildren` / `FindFirstChild` / `FindFirstChildOfClass`
   / `FindFirstChildWhichIsA` looking for `Folder`s, re-parents things
8. Uses a `NumberRange`
9. On teardown: `workspace` … `:Destroy()`
Elsewhere it uses `SetAttribute`/`GetAttribute(s)`, creates `Part`/`Folder`,
checks `ClassName`, and requires `workspace.part` to exist.

This is consistent with a **per-frame visual script keyed off `workspace.part`**
(raycast + CFrame math driving a Color3-lerped, NumberSequence-shaped beam/trail
under a Folder in a Model). The **exact per-frame math is inside the two
`workspace.Changed` handlers**, whose bodies did not run in the synchronous trace
(no events fired), so they are not yet in the constant stream.

## Event trace result (Edit mode) — no deferred handlers exist
Ran the tracer, then fired every plausible trigger and watched the traced VM:
- 150 `workspace.part` property changes (Size/CFrame/Transparency/Color/Anchored/
  CanCollide) -> `part.Changed` fired 150x
- `workspace.Changed` via Gravity / FallenPartsDestroyHeight toggles
- `workspace.ChildAdded` / `DescendantAdded` via new parts
- attribute changes

**Zero VM instructions executed in response to any of them** (handler stream
length = 0 every time). Combined with: no `RunService`/`Heartbeat`/`Stepped` in
the 77 constants, and zero `spawn`/`task.spawn` callbacks captured, the
conclusion is definitive: **this payload installs no live event/per-frame handler
that runs VM code.** The `Changed` and `spawn`/`defer`/`delay` tokens seen in the
stream were the anti-tamper gauntlet *exercising* those APIs, not your code wiring
callbacks.

So the setup trace (11,163 resolutions) is the **complete** runtime behavior in
this environment. The payload runs once at load: does the API sequence above, and
where it looks for game objects (`FindFirstChild`/`FindFirstChildWhichIsA` on a
`Model`/`Folder`) it finds nothing in an empty Test place, so those branches
short-circuit. Any logic gated on the *real target game* (a specific Model/Folder
layout, a character, a RemoteEvent, user input) cannot be triggered here — it
would require running inside that actual game, or a full static VM lifter.

(Note: one automated window-extraction step and the Play-mode server run were
blocked by the sandbox's security classifier this session; the Edit-mode event
trace above is what produced the definitive result.)
