--!nocheck
-- this_build_trace.lua  (auto-generated, build-independent)
-- 1) server up (unobf.py --serve)  2) Studio View->Command Bar  3) paste, Enter.
local BASE = "http://127.0.0.1:8799/"
local HttpService = game:GetService("HttpService")
local loaderSrc = HttpService:GetAsync(BASE.."loader_capture.lua")
local payload   = HttpService:GetAsync(BASE.."payload.bin")
local realenv = getfenv()
local genv = {}
local ES = {
 identifyexecutor=function() return "Synapse X","2.0" end, getexecutorname=function() return "Synapse X" end,
 getgenv=function() return genv end, getrenv=function() return realenv end, getreg=function() return {} end, getgc=function() return {} end,
 getrawmetatable=function(o) local ok,m=pcall(getmetatable,o); return ok and m or nil end, setrawmetatable=function(o) return o end,
 setreadonly=function() end, isreadonly=function() return false end, make_writeable=function() end, make_readonly=function() end,
 hookfunction=function(a) return a end, replaceclosure=function(a) return a end, hookmetamethod=function() return function() end end,
 newcclosure=function(f) return f end, clonefunction=function(f) return f end, checkcaller=function() return true end,
 islclosure=function() return true end, iscclosure=function() return false end, getnamecallmethod=function() return "" end, setnamecallmethod=function() end,
 getcallingscript=function() return nil end, getscriptclosure=function() return function() end end, getscripthash=function() return "" end,
 request=function() return {StatusCode=200,Body="",Success=true} end, getconnections=function() return {} end,
 getinstances=function() return {} end, getnilinstances=function() return {} end, cloneref=function(x) return x end,
 compareinstances=function(a,b) return a==b end, setclipboard=function() end, fireclickdetector=function() end,
 firetouchinterest=function() end, firesignal=function() end, isnetworkowner=function() return true end,
 getthreadidentity=function() return 8 end, setthreadidentity=function() end, checkclosure=function() return true end,
 isourclosure=function() return true end, isexecutorclosure=function() return true end,
}
local part = workspace:FindFirstChild("part") or Instance.new("Part")
part.Name="part"; part.Anchored=true; part.Parent=workspace

-- gauntlet signature: 64-hex integrity hashes (cheap pattern match, not a byte loop).
local function isGauntlet(s)
  return #s>=32 and s:match("^[0-9a-f]+$")~=nil
end

-- proxy for arithmetic taint (no __lt/__le: Luau lacks them; offenders get blacklisted)
local PMT={}
local function uw(x) if type(x)=="table" and rawget(x,"__t") then return x.__v end return x end
local function pe(x) if type(x)=="table" and rawget(x,"__t") then return x.__e end return tostring(x) end
local function mk(v,e) return setmetatable({__t=true,__v=v,__e=e},PMT) end
local OPS
local function bin(sym,nm,f) return function(a,b) local r=f(uw(a),uw(b))
  OPS[#OPS+1]=("%s(%s , %s) = %s"):format(nm,pe(a),pe(b),tostring(r)); return mk(r,"("..pe(a)..sym..pe(b)..")") end end
PMT.__add=bin("+","ADD",function(a,b)return a+b end); PMT.__sub=bin("-","SUB",function(a,b)return a-b end)
PMT.__mul=bin("*","MUL",function(a,b)return a*b end); PMT.__div=bin("/","DIV",function(a,b)return a/b end)
PMT.__mod=bin("%%","MOD",function(a,b)return a%%b end); PMT.__pow=bin("^","POW",function(a,b)return a^b end)
PMT.__unm=function(a) OPS[#OPS+1]="UNM("..pe(a)..")"; return mk(-uw(a),"(-"..pe(a)..")") end
PMT.__tostring=function(a) return tostring(uw(a)) end
PMT.__concat=function(a,b) return pe(a)..pe(b) end

-- ==== PASS 0: no taint, collect stream (ring buffer = last RING) + boundary ====
-- Heavy builds emit hundreds of thousands of resolutions (byte-by-byte decode); the
-- real script code is at the very END, so we keep only the last RING entries. This
-- keeps the hook O(1) and fast even for 500k+ resolutions.
-- Capture strategy for heavy builds: the decode/gauntlet NOISE is almost all
-- NUMBERS (85, 256, 16777216, hashes). The real script code is made of STRINGS
-- (bxor, IsA, GetService, print, keys...) plus a few adjacent numbers (e.g. bxor 7).
-- So we KEEP every string token + a few numbers right after each string, and only
-- ring-buffer the rest. This captures the logic wherever it sits in millions of ops.
local KEEPCAP = 30000
local RING = 1500
local behavior, cap, INNER = {}, {}, {}
local boundary, total = 0, 0
local keep = {}            -- meaningful tokens (strings + adjacent numbers)
local ring, rpos = {}, 0   -- tail context
do
  local function logb(k,...) local p={} for i=1,select("#",...) do p[i]=tostring((select(i,...))) end behavior[#behavior+1]=k..": "..table.concat(p," | ") end
  local env=setmetatable({},{__index=function(_,k) local rv=realenv[k]; if rv~=nil then return rv end return ES[k] end})
  env.__CAP=function(d,t) cap.eU=d; cap.Gt=t end
  -- instruction-level hook (component B): record executed pc sequence, compressed
  -- with run-length so millions of instructions stay cheap. Gives control flow.
  local pcExec, pcDistinct, pcSeq, lastPC, runLen = 0, {}, {}, nil, 0
  env.__PC=function(pc)
    pcExec=pcExec+1
    if not pcDistinct[pc] then pcDistinct[pc]=true; PCN=(PCN or 0)+1 end
    if pc==lastPC then runLen=runLen+1
    else if lastPC~=nil and #pcSeq<8000 then pcSeq[#pcSeq+1]=lastPC.."x"..runLen end
      lastPC=pc; runLen=1 end
  end
  _G.__pcstats=function() if lastPC~=nil and #pcSeq<8000 then pcSeq[#pcSeq+1]=lastPC.."x"..runLen end
    return pcExec, PCN or 0, pcSeq end
  local keepNext=0
  env.__SL=function(r)
    total=total+1
    local tp=type(r)
    local s
    if tp=="string" then s="S:"..r; if isGauntlet(r) then boundary=total end
    elseif tp=="number" then s="N:"..tostring(r)
    elseif tp=="boolean" then s="B:"..tostring(r) else s="?:"..tp end
    -- keep meaningful tokens
    if tp=="string" and not isGauntlet(r) then
      if #keep<KEEPCAP then keep[#keep+1]=s end
      keepNext=4                     -- also keep the next few numbers (args)
    elseif keepNext>0 then
      if #keep<KEEPCAP then keep[#keep+1]=s end
      keepNext=keepNext-1
    end
    rpos=rpos+1; ring[(rpos-1)%RING+1]=s
  end
  env.print=function(...) logb("PRINT",...) end; env.warn=function(...) logb("WARN",...) end
  env.getgenv=ES.getgenv
  -- RECURSIVE CAPTURE: any inner script the loader loadstring's is a deeper layer.
  -- We grab its source so it can be re-processed by unobf.py (nested obfuscation).
  env.loadstring=function(s,...)
    if type(s)=="string" and #s>200 then INNER[#INNER+1]=s end
    local f=loadstring(s,...); if f then setfenv(f,env) end return f end
  local RI=realenv.Instance
  env.Instance=setmetatable({},{__index=function(_,k) if k=="new" then return function(c,...) logb("Instance.new",c); return RI.new(c,...) end end return RI[k] end})
  local rt=realenv.task; local wn=0
  env.wait=function() wn=wn+1; if wn>3 then error("WB") end return 0 end
  env.task=setmetatable({},{__index=function(_,k) if k=="wait" then return env.wait end return rt[k] end})
  local f=loadstring(loaderSrc); setfenv(f,env); pcall(f,payload)
end

-- Build the stream: the KEPT meaningful tokens (strings + adjacent numbers, in
-- order) followed by the tail-ring for context. This preserves code that sits
-- anywhere in the run, not just at the end.
local stream = {}
for i=1,#keep do stream[#stream+1]=keep[i] end
do
  local n = math.min(rpos, RING)
  stream[#stream+1]="---tail---"
  for i=0,n-1 do local k=rpos-n+1+i; stream[#stream+1]=ring[(k-1)%RING+1] end
end

-- pull instruction-level (pc) stats captured by the __PC hook
local pcExec, pcDistinct, pcSeq = 0, 0, {}
if __pcstats then pcExec, pcDistinct, pcSeq = __pcstats() end

-- RECURSIVE: POST any captured inner-layer scripts back so unobf.py can re-process
-- them (nested obfuscation). Saved server-side as inner1.txt, inner2.txt, ...
if #INNER > 0 then
  print("DIAG captured "..#INNER.." inner layer(s); posting for re-processing")
  for i=1,#INNER do
    pcall(function() HttpService:PostAsync(BASE.."inner"..i, INNER[i]) end)
  end
end

-- POST the stream/behavior result IMMEDIATELY (before the heavy taint loop) so we
-- always get the structure even if the taint pass later times out.
local function buildOut(OPS, okv)
  local out={}
  out[#out+1]="== LAYER 2 TRACE (auto) =="
  out[#out+1]="final run ok: "..tostring(okv)
  out[#out+1]="captured decoder+table: "..tostring(cap.eU~=nil and cap.Gt~=nil)
  out[#out+1]="resolution total: "..total.."  (kept last "..#stream..")"
  out[#out+1]="payload boundary index: "..boundary
  out[#out+1]="instructions executed (pc): "..pcExec.."   distinct pc: "..pcDistinct
  out[#out+1]="arithmetic ops captured: "..#OPS
  out[#out+1]="---- ARITHMETIC OPS (payload, execution order) ----"
  for _,o in ipairs(OPS) do out[#out+1]=o end
  out[#out+1]="---- BEHAVIOR ----"
  for _,l in ipairs(behavior) do out[#out+1]=l end
  out[#out+1]="---- RESOLUTION STREAM (meaningful "..#keep.." + tail) ----"
  for i=1,#stream do out[#out+1]=stream[i] end
  out[#out+1]="---- CONTROL FLOW (pc x runlength, first "..#pcSeq..") ----"
  for i=1,#pcSeq do out[#out+1]=pcSeq[i] end
  return table.concat(out,"\n")
end
pcall(function() HttpService:PostAsync(BASE.."result", buildOut({}, "pass0")) end)

-- ==== PASSES 1..N: arithmetic taint, self-healing over comparison crashes ====
-- task.wait() between attempts yields so Studio does not kill us for "exhausted
-- execution time". Attempts kept small; each re-runs the whole VM.
local blacklist={}   -- wrap-ordinals to skip (they get compared -> would crash)
local bestOPS, lastOK = {}, false
-- HEAVY-BUILD GUARD: a single VM run on a huge build can exceed Studio's script
-- timeout, and that happens INSIDE one run (task.wait can't interrupt it). So if
-- the stream is large we SKIP the taint pass entirely -- pass-0 (already POSTed)
-- carries the structure; arithmetic isn't needed for such builds.
local HEAVY = (total >= 120000) or (boundary >= 60000)
local TAINT_T0 = os.clock()
for attempt=1,(HEAVY and 0 or 8) do
  task.wait()
  if os.clock()-TAINT_T0 > 5 then break end
  OPS={}
  local ok,err
  do
    local env=setmetatable({},{__index=function(_,k) local rv=realenv[k]; if rv~=nil then return rv end return ES[k] end})
    env.__CAP=function() end
    local cnt=0; local wrapN=0; local lastWrap=0; local prevKey=false
    env.__SL=function(r) cnt=cnt+1
      if type(r)=="string" then
        prevKey = (#r<=4 and r:match("^%a[%w_]*$")~=nil and not isGauntlet(r))
      elseif type(r)=="number" then
        if cnt>boundary and prevKey then
          wrapN=wrapN+1; prevKey=false
          if not blacklist[wrapN] then lastWrap=wrapN; return mk(r,tostring(r)) end
        end
        prevKey=false
      end
      return nil
    end
    env.__lastWrap=function() return lastWrap end
    env.print=function() end; env.warn=function() end; env.getgenv=ES.getgenv
    env.loadstring=function(s,...) local f=loadstring(s,...); if f then setfenv(f,env) end return f end
    local RI=realenv.Instance
    env.Instance=setmetatable({},{__index=function(_,k) if k=="new" then return function(c,...) return RI.new(c,...) end end return RI[k] end})
    local rt=realenv.task; local wn=0
    env.wait=function() wn=wn+1; if wn>3 then error("WB") end return 0 end
    env.task=setmetatable({},{__index=function(_,k) if k=="wait" then return env.wait end return rt[k] end})
    local f=loadstring(loaderSrc); setfenv(f,env)
    ok,err=pcall(f,payload)
    if not ok and tostring(err):find("compare") then
      -- a wrapped value hit a comparison: blacklist the last one wrapped, retry
      if lastWrap>0 then blacklist[lastWrap]=true end
    end
    _G.__lw=lastWrap
  end
  if #OPS>=#bestOPS then bestOPS=OPS end
  lastOK = ok
  if ok then break end
end

pcall(function() HttpService:PostAsync(BASE.."result", buildOut(bestOPS, lastOK)) end)
print("== TRACE DONE ==  ok:",lastOK,"  ops:",#bestOPS,"  total:",total,"  kept:",#stream,"  boundary:",boundary)
for i=1,#bestOPS do print(bestOPS[i]) end
