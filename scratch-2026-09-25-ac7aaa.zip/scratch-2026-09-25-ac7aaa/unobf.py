#!/usr/bin/env python3
"""
unobf.py - Deobfuscator / analysis tool for khaled's custom Roblox Lua obfuscator.

Handles Layer 1 fully in pure Python (auto-detected per-build knobs):
    Base85(custom alphabet) -> Zstd -> 8-byte masked header -> split(loader, payload)

Layer 2 (the stack VM) requires REAL Roblox Studio because of its datatype
anti-tamper gauntlet, so this tool DUMPS loader/payload and EMITS a Studio
logging plugin (--emit-plugin) to finish the VM step there.

Key features:
  * Nothing is hardcoded per build. It reads the alphabet, data key, endianness
    and masks straight out of the decoder function's source text.
  * DECOY FILTER: the obfuscator plants fake alphabets / fake [NNN]=[[...]] blobs
    / fake decoder loops. This tool never trusts a candidate by looks; it TRIES
    to decode each one and keeps only the candidate that yields valid Zstd + a
    sane header. Decoys are reported, not used.
  * VERSION PROFILES: 25ms, khaled, 25ms_version_khaled (auto-detected, override
    with --version).

Usage:
    python unobf.py obfuscated.lua
    python unobf.py obfuscated.lua -o out/ --version 25ms_version_khaled
    python unobf.py obfuscated.lua --emit-plugin
    python unobf.py obfuscated.lua --scan-only      # just report decoys/knobs

Requires: pip install zstandard
"""

import argparse
import os
import re
import sys

try:
    import zstandard
except ImportError:
    zstandard = None


# --------------------------------------------------------------------------- #
# Version profiles. Each build family may combine header bytes differently or
# lay the blob out differently. Values of None mean "auto-detect from source".
# --------------------------------------------------------------------------- #
PROFILES = {
    "25ms": {
        "endianness": None,
        "group_size": 5,          # base85: 5 chars -> 4 bytes
        "bytes_per_group": 4,
        "header_len": 8,
    },
    "khaled": {
        "endianness": None,
        "group_size": 5,
        "bytes_per_group": 4,
        "header_len": 8,
    },
    "25ms_version_khaled": {
        "endianness": None,
        "group_size": 5,
        "bytes_per_group": 4,
        "header_len": 8,
    },
}
DEFAULT_PROFILE = "25ms_version_khaled"


class Report:
    """Collects human-readable findings so --scan-only can print without decoding."""
    def __init__(self):
        self.lines = []
        self.decoys = []

    def add(self, msg):
        self.lines.append(msg)

    def decoy(self, msg):
        self.decoys.append(msg)

    def dump(self):
        for l in self.lines:
            print("  " + l)
        if self.decoys:
            print("\n[decoys] rejected / suspicious constructs:")
            for d in self.decoys:
                print("  x " + d)
        else:
            print("\n[decoys] none flagged")


# --------------------------------------------------------------------------- #
# Knob extraction  (STEP 1 of the walkthrough)
# --------------------------------------------------------------------------- #
def find_alphabets(src):
    """
    Return every 85-char string that looks like a base85 alphabet.
    The real one is loaded by a `for i=1,85 do LM[sub(ALPHABET,i,i)]=i-1 end`
    style loop, but decoys plant extra 85-char literals. We return all
    candidates; the decode test decides which is real.
    """
    cands = []
    # Any long-bracket or quoted string literal exactly 85 unique-ish chars long.
    # Grab quoted literals first.
    for m in re.finditer(r'(["\'])((?:\\.|(?!\1).){80,120})\1', src, re.S):
        s = _unescape_lua(m.group(2))
        if len(s) == 85 and len(set(s)) == 85:
            cands.append(s)
    # Long-bracket literals [[ ... ]] of length 85
    for m in re.finditer(r"\[\[(.{85}?)\]\]", src, re.S):
        s = m.group(1)
        if len(s) == 85 and len(set(s)) == 85:
            cands.append(s)
    # Dedup preserving order
    seen, out = set(), []
    for c in cands:
        if c not in seen:
            seen.add(c)
            out.append(c)
    return out


def find_blobs(src):
    """
    Return list of (key:int, blob:str) for every  [NNNNNN]=[[ ... ]]  entry.
    Decoys plant extra ones; only one decodes cleanly.
    """
    out = []
    # [KEY]=[[ ... ]]  or  [KEY]=[=[ ... ]=]  or any long-bracket level [==[ ... ]==]
    for m in re.finditer(r"\[(\d+)\]\s*=\s*\[(=*)\[(.*?)\]\2\]", src, re.S):
        out.append((int(m.group(1)), m.group(3)))
    return out


def find_masks(src):
    """Header masks appear as  ( ... - <CONST>) % 4294967296 ."""
    masks = re.findall(r"-\s*(\d{6,})\s*\)\s*%\s*4294967296", src)
    # also tolerate 0x forms
    masks += [str(int(x, 16)) for x in re.findall(r"-\s*(0x[0-9a-fA-F]+)\s*\)\s*%\s*4294967296", src)]
    return [int(x) for x in masks]


def detect_endianness(src):
    """
    Big-endian if we see byte(F,1)*16777216 (i.e. first byte * 2^24).
    Little-endian if the first byte is multiplied by 1 / last by 2^24.
    """
    # big-endian: first byte is the high byte  ->  byte(F,1)*16777216
    if re.search(r"\(\s*[A-Za-z_]\w*\s*,\s*1\s*\)\s*\*\s*16777216", src):
        return "big"
    # little-endian: first byte is *1 and the 4th byte is *16777216
    #   e.g.  Uu(K,1)+Uu(K,2)*256+Uu(K,3)*65536+Uu(K,4)*16777216
    if re.search(r"\*\s*256\b", src) and re.search(r"\*\s*16777216", src):
        return "little"
    return "little"


def _unescape_lua(s):
    return (s.replace(r"\\", "\\").replace(r"\"", '"').replace(r"\'", "'")
             .replace(r"\n", "\n").replace(r"\t", "\t").replace(r"\r", "\r"))


# --------------------------------------------------------------------------- #
# Layer 1 decode  (STEP 2)
# --------------------------------------------------------------------------- #
def base85_decode(blob, alphabet, endianness, group_size, bytes_per_group):
    lm = {c: i for i, c in enumerate(alphabet)}
    # A decoy alphabet won't cover the blob's charset -> KeyError -> rejected.
    out = bytearray()
    v = n = 0
    order = endianness
    for ch in blob:
        if ch not in lm:
            raise ValueError(f"char {ch!r} not in alphabet (wrong candidate)")
        v = v * 85 + lm[ch]
        n += 1
        if n == group_size:
            out += (v % 2 ** 32).to_bytes(bytes_per_group, order)
            v = n = 0
    if n > 1:
        for _ in range(group_size - n):
            v = v * 85 + (len(alphabet) - 1)
        out += (v % 2 ** 32).to_bytes(bytes_per_group, order)[: n - 1]
    return bytes(out)


def try_decode(blob, alphabet, profile, masks, report, label=""):
    """
    Attempt full Layer-1 decode for one (blob, alphabet) pair.
    Returns dict(loader, payload, len_loader, len_payload) or None.
    A decoy fails here (bad chars / not zstd / insane header lengths).
    """
    if zstandard is None:
        raise SystemExit("zstandard not installed. Run: pip install zstandard")

    # The base85 GROUP packing order and the HEADER order can differ per build
    # (this build packs groups big-endian but reads the header little-endian),
    # so we try them independently instead of coupling them.
    group_orders = [profile["endianness"]] if profile["endianness"] else ["big", "little"]
    hlen = profile["header_len"]

    for gorder in group_orders:
        try:
            raw = base85_decode(blob, alphabet, gorder,
                                profile["group_size"], profile["bytes_per_group"])
        except ValueError as e:
            report.decoy(f"{label}: base85 failed ({e})")
            return None
        try:
            data = zstandard.ZstdDecompressor().decompress(raw, max_output_size=200_000_000)
        except Exception:
            if raw[:4] != b"\x28\xb5\x2f\xfd":
                report.decoy(f"{label}: group-order={gorder} -> not a Zstd stream (decoy or wrong order)")
                continue
            report.decoy(f"{label}: Zstd magic ok but decompress failed")
            continue

        if len(data) < hlen + 2:
            report.decoy(f"{label}: decompressed too small -> decoy")
            continue

        for horder in ("little", "big"):
            len_loader = int.from_bytes(data[0:4], horder)
            len_payload = int.from_bytes(data[4:8], horder)
            best = _apply_masks(len_loader, len_payload, masks, len(data) - hlen)
            if best is None:
                continue
            len1, len2 = best   # header order: len1 = first segment, len2 = second
            seg1 = data[hlen:hlen + len1]
            seg2 = data[hlen + len1:hlen + len1 + len2]
            # Runtime does `loadstring(seg2)(seg1)`: seg2 is the VM SOURCE (loader),
            # seg1 is the argument it consumes (payload). Fall back to a text-check
            # in case a build lays them out the other way round.
            if seg1[:16].lstrip()[:5] in (b"local", b"retur", b"do lo") and seg2[:5] not in (b"local", b"retur"):
                loader, payload, ll, lp = seg1, seg2, len1, len2
            else:
                loader, payload, ll, lp = seg2, seg1, len2, len1
            report.add(f"{label}: OK  group-order={gorder}  header-order={horder}  "
                       f"loader={ll:,}  payload={lp:,}")
            return {"loader": loader, "payload": payload, "len_loader": ll,
                    "len_payload": lp, "endian": f"group={gorder}/header={horder}"}
        report.decoy(f"{label}: header lengths never fit body under either order/masks")
    return None


def _apply_masks(a, b, masks, body_len):
    """Find mask pair (ma, mb) s.t. (a-ma)%2^32 + (b-mb)%2^32 fits in body_len."""
    M = 2 ** 32
    candidates = masks + [0]
    for ma in candidates:
        la = (a - ma) % M
        if la > body_len:
            continue
        for mb in candidates:
            lb = (b - mb) % M
            if 0 < la and 0 <= lb and la + lb <= body_len and la + lb >= body_len - 64:
                return la, lb
    # looser: just require both lengths sane and sum <= body
    for ma in candidates:
        la = (a - ma) % M
        for mb in candidates:
            lb = (b - mb) % M
            if 0 < la <= body_len and 0 <= lb <= body_len and la + lb <= body_len:
                return la, lb
    return None


# --------------------------------------------------------------------------- #
# Driver
# --------------------------------------------------------------------------- #
def auto_version(src):
    if re.search(r"25ms.*khaled|khaled.*25ms", src, re.I):
        return "25ms_version_khaled"
    if re.search(r"khaled", src, re.I):
        return "khaled"
    if re.search(r"25ms", src, re.I):
        return "25ms"
    return DEFAULT_PROFILE


def run(path, outdir, version, scan_only, emit_plugin):
    src = open(path, encoding="latin1").read()
    print(f"[+] loaded {path}  ({len(src):,} chars)")

    version = version or auto_version(src)
    profile = PROFILES[version]
    print(f"[+] version profile: {version}")

    report = Report()
    alphabets = find_alphabets(src)
    blobs = find_blobs(src)
    masks = find_masks(src)
    endian = detect_endianness(src)
    if not profile["endianness"]:
        profile = dict(profile, endianness=None)  # keep auto-try

    print(f"\n[scan] alphabets found : {len(alphabets)} "
          f"({'>1 -> decoys present' if len(alphabets) > 1 else 'clean'})")
    print(f"[scan] data blobs found: {len(blobs)} keys="
          f"{[k for k, _ in blobs]}")
    print(f"[scan] header masks    : {masks or 'none found'}")
    print(f"[scan] endianness hint : {endian}")

    if len(alphabets) > 1:
        for a in alphabets[1:]:
            report.decoy(f"extra 85-char alphabet literal (likely fake): {a[:20]}...")
    if len(blobs) > 1:
        report.add(f"{len(blobs)} blobs -> will decode-test each; only the real one survives")

    # Try every (blob, alphabet) combination; the decode test rejects decoys.
    result = None
    for key, blob in sorted(blobs, key=lambda kv: -len(kv[1])):  # real blob usually largest
        for alpha in alphabets or [None]:
            if alpha is None:
                report.decoy("no alphabet literal found at all")
                continue
            label = f"blob[{key}] x alphabet[{alpha[:8]}..]"
            r = try_decode(blob, alpha, profile, masks, report, label)
            if r:
                r["key"] = key
                r["alphabet"] = alpha
                result = r
                break
        if result:
            break

    print("\n[report]")
    report.dump()

    if scan_only:
        return 0
    if not result:
        print("\n[!] Layer 1 failed: no candidate decoded cleanly. "
              "The real blob/alphabet may use a variant not covered by this profile.")
        return 2

    os.makedirs(outdir, exist_ok=True)
    lp = os.path.join(outdir, "loader.lua")
    pp = os.path.join(outdir, "payload.bin")
    with open(lp, "wb") as f:
        f.write(result["loader"])
    with open(pp, "wb") as f:
        f.write(result["payload"])
    print(f"\n[+] Layer 1 done.")
    print(f"    real data key : [{result['key']}]")
    print(f"    endianness    : {result['endian']}")
    print(f"    loader  -> {lp}  ({result['len_loader']:,} bytes)  <- the VM source")
    print(f"    payload -> {pp}  ({result['len_payload']:,} bytes)")
    print(f"\n    Original runtime does:  loadstring(loader)(payload)")
    print(f"    Loader head: {result['loader'][:80]!r}")

    if emit_plugin:
        plug = os.path.join(outdir, "vm_logger.server.lua")
        with open(plug, "w", encoding="utf-8") as f:
            f.write(STUDIO_PLUGIN)
        print(f"\n[+] Studio VM-logging plugin -> {plug}")
        print("    (STEP 3: run inside real Roblox Studio to defeat the VM anti-tamper)")
    return 0


# --------------------------------------------------------------------------- #
# STEP 3 helper: Studio plugin that hooks the VM via setfenv/getfenv logging,
# keeping game/datatypes REAL and wrapping only print/warn/loadstring/Instance.new.
# --------------------------------------------------------------------------- #
STUDIO_PLUGIN = r'''-- vm_logger.server.lua  (paste WHOLE obfuscated script into WHOLE_SCRIPT)
-- STEP 3 of unobf: run the script with a logging fenv to dump VM behavior.
-- Keep game + every datatype REAL, or the anti-tamper typeof() checks crash.
local WHOLE_SCRIPT = [==[ <paste the full obfuscated .lua here> ]==]

local log = {}
local function record(kind, ...)
    local parts = {}
    for i = 1, select("#", ...) do parts[i] = tostring((select(i, ...))) end
    table.insert(log, kind .. ": " .. table.concat(parts, ", "))
end

local realG = getfenv(0)
local env = setmetatable({}, {__index = realG})   -- fall through to REAL globals
env.print      = function(...) record("PRINT", ...) end
env.warn       = function(...) record("WARN", ...)  end
env.Instance   = setmetatable({ new = function(cls, ...)
                    record("Instance.new", cls); return Instance.new(cls, ...) end },
                    {__index = Instance})
local realLoad = loadstring
env.loadstring = function(chunk, ...)
    local fn = realLoad(chunk, ...)
    if fn then pcall(setfenv, fn, env) end
    record("loadstring", "#" .. tostring(#tostring(chunk)))
    return fn
end
-- game, workspace, typeof, task, etc. stay REAL via __index.

local f = assert(realLoad(WHOLE_SCRIPT))
setfenv(f, env)
local ok, err = pcall(f)
record(ok and "RUN_OK" or "RUN_ERR", tostring(err))

print("================ VM LOG ================")
for _, l in ipairs(log) do print(l) end
print("========================================")
-- Then decrypt constants: inject __EX(function() return Nu, Rd end) before the
-- resolver, and after the run do:  for i=1,#Rd do print(Nu(Rd[i])) end
-- Keep only printable strings; drop junk tokens (decoy/gauntlet noise).
'''


def serve(indir, input_path, port):
    """Static server so Roblox Studio can HttpService:GetAsync the big files.
    Also accepts POST results (constants / trace) back from Studio.
    Serves: /loader.lua /payload.bin /whole.lua  and  POST /result -> saved.
    """
    import http.server, socketserver, shutil
    # make the whole original script fetchable too (STEP 3 runs it directly)
    shutil.copyfile(input_path, os.path.join(indir, "whole.lua"))

    class H(http.server.SimpleHTTPRequestHandler):
        def __init__(self, *a, **k):
            super().__init__(*a, directory=indir, **k)
        def log_message(self, *a):
            print("   [serve]", self.address_string(), a[0] % a[1:])
        def do_POST(self):
            n = int(self.headers.get("Content-Length", 0))
            body = self.rfile.read(n)
            name = self.path.strip("/").replace("/", "_") or "result"
            dst = os.path.join(indir, name + ".txt")
            with open(dst, "wb") as f:
                f.write(body)
            print(f"   [serve] <- POST {self.path}  saved {len(body):,}B -> {dst}")
            self.send_response(200); self.end_headers(); self.wfile.write(b"ok")

    os.chdir(".")
    with socketserver.TCPServer(("127.0.0.1", port), H) as httpd:
        print(f"[serve] http://127.0.0.1:{port}/  (loader.lua payload.bin whole.lua)")
        print("[serve] Ctrl+C to stop.")
        try:
            httpd.serve_forever()
        except KeyboardInterrupt:
            print("\n[serve] stopped.")


def main():
    ap = argparse.ArgumentParser(description="Deobfuscate khaled's custom Roblox Lua obfuscator (Layer 1 + VM setup).")
    ap.add_argument("input", help="obfuscated .lua file")
    ap.add_argument("-o", "--out", default="unobf_out", help="output directory")
    ap.add_argument("--version", choices=list(PROFILES), help="force version profile (default: auto)")
    ap.add_argument("--scan-only", action="store_true", help="report knobs/decoys, do not decode")
    ap.add_argument("--emit-plugin", action="store_true", help="also write the Studio VM-logging plugin")
    ap.add_argument("--serve", action="store_true", help="after decoding, serve out/ so Studio can fetch the files")
    ap.add_argument("--port", type=int, default=8799, help="port for --serve (default 8799)")
    args = ap.parse_args()
    if not os.path.isfile(args.input):
        sys.exit(f"no such file: {args.input}")
    rc = run(args.input, args.out, args.version, args.scan_only, args.emit_plugin)
    if args.serve and rc == 0 and not args.scan_only:
        serve(args.out, args.input, args.port)
    sys.exit(rc)


if __name__ == "__main__":
    main()
