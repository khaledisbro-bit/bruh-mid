-- recovered_source.lua  (auto-lifted by unobf.py --lift)
-- Logic + constants derived from the VM execution trace. Local variable
-- NAMES are auto-generated (destroyed at compile time; not in the trace).

local v_svc = game:GetService("HttpService")

local v_data = {
    { n = "Alpha", v = 17 },
    { n = "Beta", v = 42 },
    { n = "Gamma", v = 9 },
}

local function fn_map(t)
    local r = {}
    for i = 1, #t do
        local x = t[i]
        r[x.n] = (x.v * 3) - i
    end
    return r
end

local v_result = fn_map(v_data)
local v_encoded = v_svc:JSONEncode(v_result)
print(v_encoded)
