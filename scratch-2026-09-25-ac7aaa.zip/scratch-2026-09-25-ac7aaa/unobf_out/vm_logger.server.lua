-- vm_logger.server.lua  (paste WHOLE obfuscated script into WHOLE_SCRIPT)
-- STEP 3 of unobf: run the script with a logging fenv to dump VM behavior.
-- Keep game + every datatype REAL, or the anti-tamper typeof() checks crash.
local WHOLE_SCRIPT = [==[ <paste the full obfuscated .lua here> ]==]

local log = {}
local function record(kind, ...)
    local parts = {}
    for i = 1, select("#", ...) do parts[i] = tostring((select(i, ...))) end
    table.insert(log, kind .. ": " .. table.concat(parts, ", "))
end

local realG = getfenv(0)
local env = setmetatable({}, {__index = realG})   -- fall through to REAL globals
env.print      = function(...) record("PRINT", ...) end
env.warn       = function(...) record("WARN", ...)  end
env.Instance   = setmetatable({ new = function(cls, ...)
                    record("Instance.new", cls); return Instance.new(cls, ...) end },
                    {__index = Instance})
local realLoad = loadstring
env.loadstring = function(chunk, ...)
    local fn = realLoad(chunk, ...)
    if fn then pcall(setfenv, fn, env) end
    record("loadstring", "#" .. tostring(#tostring(chunk)))
    return fn
end
-- game, workspace, typeof, task, etc. stay REAL via __index.

local f = assert(realLoad(WHOLE_SCRIPT))
setfenv(f, env)
local ok, err = pcall(f)
record(ok and "RUN_OK" or "RUN_ERR", tostring(err))

print("================ VM LOG ================")
for _, l in ipairs(log) do print(l) end
print("========================================")
-- Then decrypt constants: inject __EX(function() return Nu, Rd end) before the
-- resolver, and after the run do:  for i=1,#Rd do print(Nu(Rd[i])) end
-- Keep only printable strings; drop junk tokens (decoy/gauntlet noise).
