-- recovered_source_obf3.lua
-- NOTE: obf3 (س.lua) decoded to the SAME script as obf2 (identical handler stream:
-- CharacterAdded / task.wait(1) / BaseParts loop / CanCollide=false / print "<name> parts: 7").
-- So this is the same recovered source. Derived from the trace, not copy-pasted.

local Players = game:GetService("Players")

Players.PlayerAdded:Connect(function(player)
    player.CharacterAdded:Connect(function(character)
        task.wait(1)
        local count = 0
        for _, part in ipairs(character:GetChildren()) do
            if part:IsA("BasePart") then
                part.CanCollide = false
                count = count + 1
            end
        end
        print(player.Name .. " parts: " .. tostring(count))
    end)
end)
