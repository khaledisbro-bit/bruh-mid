--!nocheck
-- this_build_trace.lua  (auto-generated, build-independent)
-- 1) server up (unobf.py --serve)  2) Studio View->Command Bar  3) paste, Enter.
local BASE = "http://127.0.0.1:8799/"
local HttpService = game:GetService("HttpService")
local loaderSrc = HttpService:GetAsync(BASE.."loader_capture.lua")
local payload   = HttpService:GetAsync(BASE.."payload.bin")
local realenv = getfenv()
local genv = {}
local ES = {
 identifyexecutor=function() return "Synapse X","2.0" end, getexecutorname=function() return "Synapse X" end,
 getgenv=function() return genv end, getrenv=function() return realenv end, getreg=function() return {} end, getgc=function() return {} end,
 getrawmetatable=function(o) local ok,m=pcall(getmetatable,o); return ok and m or nil end, setrawmetatable=function(o) return o end,
 setreadonly=function() end, isreadonly=function() return false end, make_writeable=function() end, make_readonly=function() end,
 hookfunction=function(a) return a end, replaceclosure=function(a) return a end, hookmetamethod=function() return function() end end,
 newcclosure=function(f) return f end, clonefunction=function(f) return f end, checkcaller=function() return true end,
 islclosure=function() return true end, iscclosure=function() return false end, getnamecallmethod=function() return "" end, setnamecallmethod=function() end,
 getcallingscript=function() return nil end, getscriptclosure=function() return function() end end, getscripthash=function() return "" end,
 request=function() return {StatusCode=200,Body="",Success=true} end, getconnections=function() return {} end,
 getinstances=function() return {} end, getnilinstances=function() return {} end, cloneref=function(x) return x end,
 compareinstances=function(a,b) return a==b end, setclipboard=function() end, fireclickdetector=function() end,
 firetouchinterest=function() end, firesignal=function() end, isnetworkowner=function() return true end,
 getthreadidentity=function() return 8 end, setthreadidentity=function() end, checkclosure=function() return true end,
 isourclosure=function() return true end, isexecutorclosure=function() return true end,
}
local part = workspace:FindFirstChild("part") or Instance.new("Part")
part.Name="part"; part.Anchored=true; part.Parent=workspace

-- gauntlet signature: ONLY 64-hex integrity hashes. (API names like GetService/
-- typeof appear in BOTH gauntlet and payload, so they must NOT mark the boundary.)
local function isGauntlet(s)
  if #s>=32 then local hex=true; for i=1,#s do local b=s:byte(i)
    if not ((b>=48 and b<=57) or (b>=97 and b<=102)) then hex=false break end end
    if hex then return true end end
  return false
end

-- proxy for arithmetic taint (no __lt/__le: Luau lacks them; offenders get blacklisted)
local PMT={}
local function uw(x) if type(x)=="table" and rawget(x,"__t") then return x.__v end return x end
local function pe(x) if type(x)=="table" and rawget(x,"__t") then return x.__e end return tostring(x) end
local function mk(v,e) return setmetatable({__t=true,__v=v,__e=e},PMT) end
local OPS
local function bin(sym,nm,f) return function(a,b) local r=f(uw(a),uw(b))
  OPS[#OPS+1]=("%s(%s , %s) = %s"):format(nm,pe(a),pe(b),tostring(r)); return mk(r,"("..pe(a)..sym..pe(b)..")") end end
PMT.__add=bin("+","ADD",function(a,b)return a+b end); PMT.__sub=bin("-","SUB",function(a,b)return a-b end)
PMT.__mul=bin("*","MUL",function(a,b)return a*b end); PMT.__div=bin("/","DIV",function(a,b)return a/b end)
PMT.__mod=bin("%%","MOD",function(a,b)return a%%b end); PMT.__pow=bin("^","POW",function(a,b)return a^b end)
PMT.__unm=function(a) OPS[#OPS+1]="UNM("..pe(a)..")"; return mk(-uw(a),"(-"..pe(a)..")") end
PMT.__tostring=function(a) return tostring(uw(a)) end
PMT.__concat=function(a,b) return pe(a)..pe(b) end

-- ==== PASS 0: no taint, collect full stream + find payload boundary ====
local stream, behavior, cap = {}, {}, {}
local boundary = 0
do
  local function logb(k,...) local p={} for i=1,select("#",...) do p[i]=tostring((select(i,...))) end behavior[#behavior+1]=k..": "..table.concat(p," | ") end
  local env=setmetatable({},{__index=function(_,k) local rv=realenv[k]; if rv~=nil then return rv end return ES[k] end})
  env.__CAP=function(d,t) cap.eU=d; cap.Gt=t end
  local cnt=0
  env.__SL=function(r) cnt=cnt+1
    if #stream<500000 then
      if type(r)=="string" then stream[#stream+1]="S:"..r; if isGauntlet(r) then boundary=cnt end
      elseif type(r)=="number" then stream[#stream+1]="N:"..tostring(r)
      elseif type(r)=="boolean" then stream[#stream+1]="B:"..tostring(r) end
    end
  end
  env.print=function(...) logb("PRINT",...) end; env.warn=function(...) logb("WARN",...) end
  env.getgenv=ES.getgenv
  env.loadstring=function(s,...) local f=loadstring(s,...); if f then setfenv(f,env) end return f end
  local RI=realenv.Instance
  env.Instance=setmetatable({},{__index=function(_,k) if k=="new" then return function(c,...) logb("Instance.new",c); return RI.new(c,...) end end return RI[k] end})
  local rt=realenv.task; local wn=0
  env.wait=function() wn=wn+1; if wn>3 then error("WB") end return 0 end
  env.task=setmetatable({},{__index=function(_,k) if k=="wait" then return env.wait end return rt[k] end})
  local f=loadstring(loaderSrc); setfenv(f,env); pcall(f,payload)
end

-- POST the stream/behavior result IMMEDIATELY (before the heavy taint loop) so we
-- always get the structure even if the taint pass later times out.
local function buildOut(OPS, okv)
  local out={}
  out[#out+1]="== LAYER 2 TRACE (auto) =="
  out[#out+1]="final run ok: "..tostring(okv)
  out[#out+1]="captured decoder+table: "..tostring(cap.eU~=nil and cap.Gt~=nil)
  out[#out+1]="resolution stream length: "..#stream
  out[#out+1]="payload boundary index: "..boundary
  out[#out+1]="arithmetic ops captured: "..#OPS
  out[#out+1]="---- ARITHMETIC OPS (payload, execution order) ----"
  for _,o in ipairs(OPS) do out[#out+1]=o end
  out[#out+1]="---- BEHAVIOR ----"
  for _,l in ipairs(behavior) do out[#out+1]=l end
  out[#out+1]="---- RESOLUTION STREAM (tail 200) ----"
  for i=math.max(1,#stream-200),#stream do out[#out+1]=stream[i] end
  return table.concat(out,"\n")
end
pcall(function() HttpService:PostAsync(BASE.."result", buildOut({}, "pass0")) end)

-- ==== PASSES 1..N: arithmetic taint, self-healing over comparison crashes ====
-- task.wait() between attempts yields so Studio does not kill us for "exhausted
-- execution time". Attempts kept small; each re-runs the whole VM.
local blacklist={}   -- wrap-ordinals to skip (they get compared -> would crash)
local bestOPS, lastOK = {}, false
for attempt=1,8 do
  task.wait()
  OPS={}
  local ok,err
  do
    local env=setmetatable({},{__index=function(_,k) local rv=realenv[k]; if rv~=nil then return rv end return ES[k] end})
    env.__CAP=function() end
    local cnt=0; local wrapN=0; local lastWrap=0; local prevKey=false
    env.__SL=function(r) cnt=cnt+1
      if type(r)=="string" then
        prevKey = (#r<=4 and r:match("^%a[%w_]*$")~=nil and not isGauntlet(r))
      elseif type(r)=="number" then
        if cnt>boundary and prevKey then
          wrapN=wrapN+1; prevKey=false
          if not blacklist[wrapN] then lastWrap=wrapN; return mk(r,tostring(r)) end
        end
        prevKey=false
      end
      return nil
    end
    env.__lastWrap=function() return lastWrap end
    env.print=function() end; env.warn=function() end; env.getgenv=ES.getgenv
    env.loadstring=function(s,...) local f=loadstring(s,...); if f then setfenv(f,env) end return f end
    local RI=realenv.Instance
    env.Instance=setmetatable({},{__index=function(_,k) if k=="new" then return function(c,...) return RI.new(c,...) end end return RI[k] end})
    local rt=realenv.task; local wn=0
    env.wait=function() wn=wn+1; if wn>3 then error("WB") end return 0 end
    env.task=setmetatable({},{__index=function(_,k) if k=="wait" then return env.wait end return rt[k] end})
    local f=loadstring(loaderSrc); setfenv(f,env)
    ok,err=pcall(f,payload)
    if not ok and tostring(err):find("compare") then
      -- a wrapped value hit a comparison: blacklist the last one wrapped, retry
      if lastWrap>0 then blacklist[lastWrap]=true end
    end
    _G.__lw=lastWrap
  end
  if #OPS>=#bestOPS then bestOPS=OPS end
  lastOK = ok
  if ok then break end
end

pcall(function() HttpService:PostAsync(BASE.."result", buildOut(bestOPS, lastOK)) end)
print("== TRACE DONE ==  ok:",lastOK,"  ops:",#bestOPS,"  stream:",#stream,"  boundary:",boundary)
for i=1,#bestOPS do print(bestOPS[i]) end
