-- store_to_place.lua  --  RUN ONCE in the Command Bar in EDIT MODE (not Play).
-- Fetches loader+payload over HTTP (Edit can reach localhost) and stores them inside
-- the place, SPLIT into <200k chunks under ReplicatedStorage.__obf_data.
-- Also enables LoadStringEnabled so the loader can run in Play mode.
local h  = game:GetService("HttpService")
local rs = game:GetService("ReplicatedStorage")
local sss = game:GetService("ServerScriptService")
pcall(function() sss.LoadStringEnabled = true end)
local BASE = "http://127.0.0.1:8799/"
local CHUNK = 180000

local old = rs:FindFirstChild("__obf_data"); if old then old:Destroy() end
local folder = Instance.new("Folder"); folder.Name = "__obf_data"; folder.Parent = rs

local function hexenc(s) return (s:gsub(".", function(c) return string.format("%02x", string.byte(c)) end)) end

local function store(name, url, hex)
    local data = h:GetAsync(url)
    if hex then data = hexenc(data) end
    local grp = Instance.new("Folder"); grp.Name = name; grp.Parent = folder
    local n = 0
    for i = 1, #data, CHUNK do
        n = n + 1
        local sv = Instance.new("StringValue")
        sv.Name = tostring(n); sv.Value = data:sub(i, i + CHUNK - 1); sv.Parent = grp
    end
    local cnt = Instance.new("IntValue"); cnt.Name = "count"; cnt.Value = n; cnt.Parent = grp
    print("stored", name, "=", #data, "bytes in", n, "chunks")
end

store("loader",  BASE .. "loader_capture.lua", false)
store("payload", BASE .. "payload.bin", true)
print("DONE + LoadStringEnabled=true. Now use play_trace_local.server.lua + Test->Start.")
