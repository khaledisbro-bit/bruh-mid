--!nocheck
-- play_trace_local.server.lua  --  PATH B: capture an event handler body.
-- Reads loader+payload from ReplicatedStorage.__obf_data (no HTTP in Play).
-- Put in ServerScriptService, then Test -> Start (1-2 players). No anti-tamper bypass.

local rs = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local data = rs:WaitForChild("__obf_data", 10)
if not data then warn("MISSING DATA: run store_to_place.lua in EDIT command bar first!"); return end
local function reassemble(name)
    local grp = data:FindFirstChild(name); if not grp then return nil end
    local n = grp:FindFirstChild("count") and grp.count.Value or 0
    local parts = {}; for i=1,n do parts[i]=grp:FindFirstChild(tostring(i)).Value end
    return table.concat(parts)
end
local function hexdec(s) return (s:gsub("%x%x", function(hh) return string.char(tonumber(hh,16)) end)) end
local names={} for _,c in ipairs(data:GetChildren()) do names[#names+1]=c.Name end
print("DIAG __obf_data groups:", table.concat(names,", "))
local rawLoader, rawPayload = reassemble("loader"), reassemble("payload")
if not rawLoader or not rawPayload then warn("MISSING loader/payload in __obf_data; re-run store."); return end
local loaderSrc, payload = rawLoader, hexdec(rawPayload)
print("loaded from place: loader="..#loaderSrc.." payload="..#payload)
local realenv = getfenv()

local ES = {
 identifyexecutor=function() return "Synapse X","2.0" end, getexecutorname=function() return "Synapse X" end,
 getgenv=function() return {} end, getrenv=function() return realenv end, getgc=function() return {} end,
 getrawmetatable=function(o) local ok,m=pcall(getmetatable,o); return ok and m or nil end,
 hookfunction=function(a) return a end, newcclosure=function(f) return f end, clonefunction=function(f) return f end,
 checkcaller=function() return true end, islclosure=function() return true end, iscclosure=function() return false end,
 getnamecallmethod=function() return "" end, getcallingscript=function() return nil end, getscripthash=function() return "" end,
 request=function() return {StatusCode=200,Body="",Success=true} end, getconnections=function() return {} end,
 cloneref=function(x) return x end, compareinstances=function(a,b) return a==b end, isnetworkowner=function() return true end,
 getthreadidentity=function() return 8 end, checkclosure=function() return true end, isexecutorclosure=function() return true end,
}
pcall(function() local p=workspace:FindFirstChild("part") or Instance.new("Part"); p.Name="part"; p.Anchored=true; p.Parent=workspace end)

local stream, behavior = {}, {}
local function logb(k,...) local p={} for i=1,select("#",...) do p[i]=tostring((select(i,...))) end behavior[#behavior+1]=k..": "..table.concat(p," | ") end
local inHandler=false
local env = setmetatable({}, {__index=function(_,k) local rv=realenv[k]; if rv~=nil then return rv end return ES[k] end})
env.__CAP=function() end
env.__SL=function(r)
  if #stream<800000 then
    if type(r)=="string" then stream[#stream+1]="S:"..r
    elseif type(r)=="number" then stream[#stream+1]="N:"..tostring(r)
    elseif type(r)=="boolean" then stream[#stream+1]="B:"..tostring(r) end
  end
  return nil   -- structure pass: no taint wrapping (avoids handler crashes)
end
env.print=function(...) logb("PRINT",...) end
env.warn=function(...) logb("WARN",...) end
env.getgenv=ES.getgenv
env.loadstring=function(s,...) local f=loadstring(s,...); if f then setfenv(f,env) end return f end
local RI=realenv.Instance
env.Instance=setmetatable({},{__index=function(_,k) if k=="new" then return function(c,...) logb("Instance.new",c); return RI.new(c,...) end end return RI[k] end})

Players.PlayerAdded:Connect(function(p) print("DIAG our PlayerAdded fired for:", p.Name) end)
print("DIAG players at start:", #Players:GetPlayers())
local t0=os.clock()
local f=loadstring(loaderSrc); setfenv(f,env)
local ok,err=pcall(f,payload)
print(string.format("DIAG setup done in %.2fs ok=%s handler connected", os.clock()-t0, tostring(ok)))
if #Players:GetPlayers()>0 then
  print("DIAG >>> a player is ALREADY here. In the Test toolbar add ONE MORE player NOW")
  print("DIAG >>> so a fresh join fires the handler.")
end
inHandler=true
local handlerMark=#stream
local waited,lastLen,stable=0,#stream,0
while waited<60 do
  task.wait(1); waited=waited+1
  local n=#stream; local np=#Players:GetPlayers()
  if n>handlerMark or np>0 then print("DIAG t="..waited.." players="..np.." handlerStream="..(n-handlerMark)) end
  if n>lastLen then lastLen=n; stable=0
  elseif n>handlerMark then stable=stable+1; if stable>=3 then break end end
end

local out={"== PATH B HANDLER TRACE =="}
out[#out+1]="setup ok: "..tostring(ok).."  err: "..tostring(err)
out[#out+1]="handler stream: "..(#stream-handlerMark)
out[#out+1]="---- BEHAVIOR ----"; for _,l in ipairs(behavior) do out[#out+1]=l end
out[#out+1]="---- HANDLER STREAM ----"; for i=handlerMark+1,#stream do out[#out+1]=stream[i] end
local sv=rs:FindFirstChild("__obf_result") or Instance.new("StringValue"); sv.Name="__obf_result"; sv.Value=table.concat(out,"\n"); sv.Parent=rs
print("== PLAY TRACE DONE ==  handler stream:", #stream-handlerMark)
