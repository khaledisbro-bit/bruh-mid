-- recovered by unobf.py smart_lift (XOR string-decryption idiom).
-- Derived from the trace: bxor loop, %mod and base key from captured
-- arithmetic, encoded strings + length guard from the stream.
-- Local names auto-generated.

local bit32 = bit32

local function transform(s, k)
    local r = {}
    for i = 1, #s do
        local c = string.byte(s, i)
        c = bit32.bxor(c, k + (i % 7))
        r[i] = string.char(c)
    end
    return table.concat(r)
end

local function decode(t)
    local out = {}
    for i = 1, #t do
        out[i] = transform(t[i], 23 + i)
    end
    return table.concat(out)
end

local parts = {
    "~z~|",
    "qzq",
    "y|z",
    "~q",
}

local value = decode(parts)
if #value > 5 then
    print("Result:", value)
end
