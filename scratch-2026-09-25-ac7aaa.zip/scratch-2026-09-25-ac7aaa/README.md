# unobf — 25ms-style ObfTest unpacker + Studio trace driver

Two-layer unpacker for your hybrid obfuscator (your outer layer + the 2023
executor-simulator VM). Layer 1 is pure Python and deterministic. Layer 2 needs
real Roblox Studio, because the embedded VM runs an anti-tamper gauntlet that
touches real Roblox datatypes and expects executor-only globals.

## Files
- `unobf.py` — Layer-1 unpacker + auto-patcher + static file server.
- `studio_trace.lua` — generated Layer-2 harness (runs inside Studio).
- `vm_structure.txt` — decoded VM program layout for this build.
- `decoded_constants.txt` — all 77 recovered string constants.

## Usage

### 1. Unpack + auto-patch (Layer 1)
```
pip install zstandard
python unobf.py "25ms_obf (1).lua" out
```
Writes to `out/`:
- `loader.lua` — the VM source (~979 KB)
- `payload.bin` — the VM bytecode/data (~88 KB)
- `loader_patched.lua` — loader with an `__CAP(NU, RD, Qt)` capture hook injected
  just before the constant resolver (auto-located; no manual offsets)
- `studio_trace.lua` — the Layer-2 harness, `BASE` prefilled
- `Payload_module.lua` — payload as base64

`unobf.py` auto-detects every per-build knob and prints them, e.g.:
```
resolver : {'nu': 'QT', 'rd': 'gH', 'off': 'gc', 'idx': 'JV', 'root': 'Qt'}
```

### 2. Serve the files
```
python unobf.py "25ms_obf (1).lua" out --serve
```
Serves `out/` on `http://127.0.0.1:8799`. If Studio posts a result back to
`/result`, it is saved as `decoded_constants.txt`, `vm_structure.txt`,
`trace_log.txt`.

### 3. Run the trace in Studio
Paste `out/studio_trace.lua` into the Studio command bar (or run via an
`execute_luau` MCP call). Two modes (edit `MODE` at the top):
- `"consts"` (default, safe): loads the patched loader under a logging env,
  captures `NU`/`RD`/`Qt` at the hook, aborts before the gauntlet runs, then
  decrypts every constant and dumps the VM structure. Creates nothing.
- `"behavior"`: full run under the logging env (the gauntlet creates ~7 throwaway
  probe instances, which the harness destroys afterward).

The harness reproduces the exact conditions needed for this build:
- **executor-simulator stubs** (`identifyexecutor`, `getgenv`, `hookfunction`,
  `getrawmetatable`, `newcclosure`, `checkcaller`, `request`, ...) — Studio lacks
  these; the 2023 VM requires them.
- **`workspace.part` seeding** — the gauntlet indexes `workspace.part` unwrapped
  and errors if absent, so the harness creates a `Part` named `part` first.
- **real `game`/datatypes kept intact** — proxying `game` fails the gauntlet's
  `typeof(game)=="DataModel"` check, so only `print`/`warn`/`loadstring`/
  `Instance.new`/`task`/`wait` are wrapped; everything else falls through to real.

## What this build is
A raycast + workspace/part manipulation script with visual output (Ray/Origin/
Direction + CFrame/Vector3 math + Color3/UDim2/NumberSequence visuals + attribute
edits). It creates no parented instances and returns nothing on load — its real
work runs through event connections that operate on `workspace.part`.

## What's fully recovered vs. not
- **Fully recovered (deterministic):** Layer-1 loader + payload; all 533
  constants (77 strings + 456 numbers); the VM program layout (see
  `vm_structure.txt`).
- **Not yet source-level:** the control flow. The payload is a VM-compiled form
  of the original source; getting readable Lua back needs either (a) a decompiler
  that decodes `Qt[12]` — subtract the per-instruction LCG to recover opcodes,
  map the ~opcode set, resolve negative operands via `QT(gH[...])`, then lift to
  Lua — or (b) driving the event connections in a Play-mode sandbox and logging
  their per-frame effect on `workspace.part`.
