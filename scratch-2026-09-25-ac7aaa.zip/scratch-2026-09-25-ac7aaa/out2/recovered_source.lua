-- recovered_source.lua  (auto-lifted by unobf.py --lift)
-- Logic + constants derived from the VM execution trace. Local variable
-- NAMES are auto-generated (destroyed at compile time; not in the trace).

local v_players = game:GetService("Players")


v_players.PlayerAdded:Connect(function(...)
    -- HANDLER BODY NOT CAPTURED: the event did not fire during the
    -- Edit-mode trace, so its instructions never executed. To recover it,
    -- the trace must DRIVE this event with a fake argument (see roadmap).
end)
