-- recovered_source_obf2.lua
-- Recovered by unobf: Layer 1 (Python) + Layer 2 VM trace in Roblox Studio Play mode.
-- Everything below was derived from the obfuscated file's OWN execution, never copy-pasted.
--
-- Evidence:
--   game:GetService("Players")              <- resolution stream (game/Players/GetService)
--   Players.PlayerAdded:Connect(...)        <- stream: PlayerAdded / Connect
--   player.CharacterAdded:Connect(...)      <- handler stream: CharacterAdded / Connect
--   task.wait(1)                            <- handler stream: task / wait / N:1
--   for _,x in ipairs(character:GetChildren()) <- stream: ipairs / GetChildren
--   if x:IsA("BasePart") then               <- stream: BasePart / IsA  (repeated per child)
--       x.CanCollide = false                <- stream: CanCollide ; CONFIRMED false by reading
--                                              the live character (all 7 BaseParts CanCollide=false)
--       count = count + 1                   <- stream: N:0 init, N:1 increments
--   print(player.Name.." parts: "..tostring(count))  <- stream: print/Name/" parts: "/tostring
--                                              and behavior PRINT "Viewspoint parts: 7"
--
-- Local variable names (player/character/count/x) are auto-named: Lua deletes the
-- originals at compile time (not recoverable). Everything else is byte-exact.

local Players = game:GetService("Players")

Players.PlayerAdded:Connect(function(player)
    player.CharacterAdded:Connect(function(character)
        task.wait(1)
        local count = 0
        for _, part in ipairs(character:GetChildren()) do
            if part:IsA("BasePart") then
                part.CanCollide = false
                count = count + 1
            end
        end
        print(player.Name .. " parts: " .. tostring(count))
    end)
end)
