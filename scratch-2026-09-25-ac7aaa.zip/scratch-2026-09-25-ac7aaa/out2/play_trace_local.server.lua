--!nocheck
-- play_trace_local.server.lua  --  reads loader+payload from ReplicatedStorage
-- (stored earlier by store_to_place.lua), so NO HTTP is needed in Play mode.
-- Put this in ServerScriptService, then Test -> Start (1 player). Legit: no anti-
-- tamper bypass; PlayerAdded fires naturally when the client joins.

local rs = game:GetService("ReplicatedStorage")
local Players = game:GetService("Players")
local data = rs:WaitForChild("__obf_data", 10)
if not data then warn("MISSING DATA: run store_to_place.lua in Edit command bar first!"); return end
local function reassemble(name)
    local grp = data:FindFirstChild(name); if not grp then return nil end
    local n = grp:FindFirstChild("count") and grp.count.Value or 0
    local parts = {}
    for i = 1, n do parts[i] = grp:FindFirstChild(tostring(i)).Value end
    return table.concat(parts)
end
local function hexdec(s) return (s:gsub("%x%x", function(hh) return string.char(tonumber(hh,16)) end)) end
-- show what is actually stored, so mismatches are obvious
local names = {} for _,c in ipairs(data:GetChildren()) do names[#names+1]=c.Name end
print("DIAG __obf_data groups:", table.concat(names, ", "))
local rawLoader  = reassemble("loader")
local rawPayload = reassemble("payload")
if not rawLoader or not rawPayload then
  warn("MISSING DATA: __obf_data is missing 'loader' or 'payload'. Run store_to_place.lua")
  warn("in the Command Bar while in EDIT mode, then Test->Start WITHOUT pressing Play in between.")
  return
end
local loaderSrc = rawLoader
local payload   = hexdec(rawPayload)   -- was hex-encoded (binary, null-safe)
print("loaded from place: loader="..#loaderSrc.." payload="..#payload)
local realenv = getfenv()

local ES = {
 identifyexecutor=function() return "Synapse X","2.0" end, getexecutorname=function() return "Synapse X" end,
 getgenv=function() return {} end, getrenv=function() return realenv end, getgc=function() return {} end,
 getrawmetatable=function(o) local ok,m=pcall(getmetatable,o); return ok and m or nil end,
 hookfunction=function(a) return a end, newcclosure=function(f) return f end, clonefunction=function(f) return f end,
 checkcaller=function() return true end, islclosure=function() return true end, iscclosure=function() return false end,
 getnamecallmethod=function() return "" end, getcallingscript=function() return nil end, getscripthash=function() return "" end,
 request=function() return {StatusCode=200,Body="",Success=true} end, getconnections=function() return {} end,
 cloneref=function(x) return x end, compareinstances=function(a,b) return a==b end, isnetworkowner=function() return true end,
 getthreadidentity=function() return 8 end, checkclosure=function() return true end, isexecutorclosure=function() return true end,
}
pcall(function() local p=workspace:FindFirstChild("part") or Instance.new("Part"); p.Name="part"; p.Anchored=true; p.Parent=workspace end)

local ops, PMT = {}, {}
local function uw(x) if type(x)=="table" and rawget(x,"__t") then return x.__v end return x end
local function pe(x) if type(x)=="table" and rawget(x,"__t") then return x.__e end return tostring(x) end
local function mk(v,e) return setmetatable({__t=true,__v=v,__e=e},PMT) end
local function bin(sym,nm,f) return function(a,b) local r=f(uw(a),uw(b))
  ops[#ops+1]=("%s(%s , %s) = %s"):format(nm,pe(a),pe(b),tostring(r)); return mk(r,"("..pe(a)..sym..pe(b)..")") end end
PMT.__add=bin("+","ADD",function(a,b)return a+b end); PMT.__sub=bin("-","SUB",function(a,b)return a-b end)
PMT.__mul=bin("*","MUL",function(a,b)return a*b end); PMT.__div=bin("/","DIV",function(a,b)return a/b end)
PMT.__mod=bin("%","MOD",function(a,b)return a%b end); PMT.__pow=bin("^","POW",function(a,b)return a^b end)
PMT.__unm=function(a) ops[#ops+1]="UNM("..pe(a)..")"; return mk(-uw(a),"(-"..pe(a)..")") end
PMT.__tostring=function(a) return tostring(uw(a)) end
PMT.__concat=function(a,b) return pe(a)..pe(b) end

local stream, behavior = {}, {}
local function logb(k,...) local p={} for i=1,select("#",...) do p[i]=tostring((select(i,...))) end behavior[#behavior+1]=k..": "..table.concat(p," | ") end
local prevKeyN, inHandler = false, false
local env = setmetatable({}, {__index=function(_,k) local rv=realenv[k]; if rv~=nil then return rv end return ES[k] end})
env.__CAP = function() end
env.__SL = function(r)
  if #stream<800000 then
    if type(r)=="string" then stream[#stream+1]="S:"..r
    elseif type(r)=="number" then stream[#stream+1]="N:"..tostring(r)
    elseif type(r)=="boolean" then stream[#stream+1]="B:"..tostring(r) end
  end
  -- taint wrapping DISABLED for this pass: we first want the full, un-crashed
  -- handler stream (structure). Arithmetic taint is a later, careful pass.
  return nil
end
env.print=function(...) logb("PRINT",...) end
env.warn=function(...) logb("WARN",...) end
env.getgenv=ES.getgenv
env.loadstring=function(s,...) local f=loadstring(s,...); if f then setfenv(f,env) end return f end
local RI=realenv.Instance
env.Instance=setmetatable({},{__index=function(_,k) if k=="new" then return function(c,...) logb("Instance.new",c); return RI.new(c,...) end end return RI[k] end})

-- DIAGNOSTIC: prove PlayerAdded fires at all in this setup (our own listener)
Players.PlayerAdded:Connect(function(p) print("DIAG our PlayerAdded fired for:", p.Name) end)
print("DIAG players at start:", #Players:GetPlayers())

local t0 = os.clock()
local f=loadstring(loaderSrc); setfenv(f,env)
local ok,err=pcall(f,payload)
logb("SETUP", ok, err)
print(string.format("DIAG setup done in %.2fs  ok=%s  handler now connected", os.clock()-t0, tostring(ok)))
if #Players:GetPlayers() > 0 then
  print("DIAG >>> a player is ALREADY here. In the Test toolbar, click the player-count")
  print("DIAG >>> box and add ONE MORE player NOW -- their join will fire the handler.")
end
local setupLen=#stream

-- wait for the natural PlayerAdded (client joins in Test->Start)
inHandler=true
local handlerMark=#stream
local waited,lastLen,stable=0,#stream,0
while waited<45 do
  task.wait(1); waited=waited+1
  local n=#stream
  local np=#Players:GetPlayers()
  if n>handlerMark or np>0 then print("DIAG t="..waited.." players="..np.." handlerStream="..(n-handlerMark)) end
  if n>lastLen then lastLen=n; stable=0
  elseif n>handlerMark then stable=stable+1; if stable>=3 then break end end
end

local out={"== obf2 PLAY (local data) HANDLER TRACE =="}
out[#out+1]="setup ok: "..tostring(ok).."  err: "..tostring(err)
out[#out+1]="setup stream: "..setupLen.."   handler stream: "..(#stream-handlerMark)
out[#out+1]="arith ops in handler: "..#ops
out[#out+1]="---- ARITHMETIC OPS (handler) ----"; for _,o in ipairs(ops) do out[#out+1]=o end
out[#out+1]="---- BEHAVIOR ----"; for _,l in ipairs(behavior) do out[#out+1]=l end
out[#out+1]="---- HANDLER STREAM ----"; for i=handlerMark+1,#stream do out[#out+1]=stream[i] end
-- try to POST back (works if you Stop and this runs in Edit-reachable ctx); else read Output
pcall(function() game:GetService("HttpService"):PostAsync("http://127.0.0.1:8799/result_handler", table.concat(out,"\n")) end)
-- also stash into ReplicatedStorage so you can copy it out even if POST is blocked
local sv=rs:FindFirstChild("__obf_result") or Instance.new("StringValue"); sv.Name="__obf_result"; sv.Value=table.concat(out,"\n"); sv.Parent=rs
print("== PLAY TRACE DONE ==  handler stream:", #stream-handlerMark, " ops:", #ops)
for i=1,#ops do print(ops[i]) end
