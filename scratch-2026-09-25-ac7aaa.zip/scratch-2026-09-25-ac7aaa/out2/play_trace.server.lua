--!nocheck
-- play_trace.server.lua  --  LEGIT handler-body capture for obf 2, no anti-tamper bypass.
--
-- WHY THIS WORKS (and doesn't weaken anything): we do NOT proxy `game`, we do NOT
-- spoof typeof, we do NOT force-fire anything. We just run the payload under a
-- logging environment and let Roblox fire PlayerAdded NATURALLY when your own
-- player joins in Play mode. The handler runs on its own; we only record it.
--
-- HOW TO RUN:
--   1) Keep the local server up:  http://127.0.0.1:8799/   (serving out2)
--   2) In Studio: create a Script inside ServerScriptService, paste this in.
--   3) Press PLAY (not Run). Your player joins -> PlayerAdded fires -> handler runs.
--   4) Watch Output, and result_handler.txt is POSTed back to the server.
--   5) Stop Play (discards everything).

local HttpService = game:GetService("HttpService")
local BASE = "http://127.0.0.1:8799/"
local loaderSrc = HttpService:GetAsync(BASE.."loader_capture.lua")
local payload   = HttpService:GetAsync(BASE.."payload.bin")
local realenv = getfenv()

-- executor-simulator stubs the VM's gauntlet expects (Studio lacks them). Logging only.
local ES = {
 identifyexecutor=function() return "Synapse X","2.0" end, getexecutorname=function() return "Synapse X" end,
 getgenv=function() return {} end, getrenv=function() return realenv end, getgc=function() return {} end,
 getrawmetatable=function(o) local ok,m=pcall(getmetatable,o); return ok and m or nil end,
 hookfunction=function(a) return a end, newcclosure=function(f) return f end, clonefunction=function(f) return f end,
 checkcaller=function() return true end, islclosure=function() return true end, iscclosure=function() return false end,
 getnamecallmethod=function() return "" end, getcallingscript=function() return nil end, getscripthash=function() return "" end,
 request=function() return {StatusCode=200,Body="",Success=true} end, getconnections=function() return {} end,
 cloneref=function(x) return x end, compareinstances=function(a,b) return a==b end, isnetworkowner=function() return true end,
 getthreadidentity=function() return 8 end, checkclosure=function() return true end, isexecutorclosure=function() return true end,
}
pcall(function()
  local p = workspace:FindFirstChild("part") or Instance.new("Part")
  p.Name="part"; p.Anchored=true; p.Parent=workspace
end)

-- arithmetic taint (same as unobf's, applied to data values inside the handler)
local ops = {}
local PMT = {}
local function uw(x) if type(x)=="table" and rawget(x,"__t") then return x.__v end return x end
local function pe(x) if type(x)=="table" and rawget(x,"__t") then return x.__e end return tostring(x) end
local function mk(v,e) return setmetatable({__t=true,__v=v,__e=e},PMT) end
local function bin(sym,nm,f) return function(a,b) local r=f(uw(a),uw(b))
  ops[#ops+1]=("%s(%s , %s) = %s"):format(nm,pe(a),pe(b),tostring(r)); return mk(r,"("..pe(a)..sym..pe(b)..")") end end
PMT.__add=bin("+","ADD",function(a,b)return a+b end); PMT.__sub=bin("-","SUB",function(a,b)return a-b end)
PMT.__mul=bin("*","MUL",function(a,b)return a*b end); PMT.__div=bin("/","DIV",function(a,b)return a/b end)
PMT.__mod=bin("%","MOD",function(a,b)return a%b end); PMT.__pow=bin("^","POW",function(a,b)return a^b end)
PMT.__unm=function(a) ops[#ops+1]="UNM("..pe(a)..")"; return mk(-uw(a),"(-"..pe(a)..")") end
PMT.__tostring=function(a) return tostring(uw(a)) end
PMT.__concat=function(a,b) return pe(a)..pe(b) end

local stream, behavior = {}, {}
local handlerMark = nil          -- stream index where the handler body starts
local function logb(k,...) local p={} for i=1,select("#",...) do p[i]=tostring((select(i,...))) end behavior[#behavior+1]=k..": "..table.concat(p," | ") end

local prevKeyN = false
local inHandler = false
local env = setmetatable({}, {__index=function(_,k) local rv=realenv[k]; if rv~=nil then return rv end return ES[k] end})
env.__CAP = function() end
env.__SL = function(r)
  if #stream<800000 then
    if type(r)=="string" then stream[#stream+1]="S:"..r
    elseif type(r)=="number" then stream[#stream+1]="N:"..tostring(r)
    elseif type(r)=="boolean" then stream[#stream+1]="B:"..tostring(r) end
  end
  -- only taint inside the handler (after the player joins), on values following key "n"
  if inHandler then
    if type(r)=="string" then prevKeyN=(#r<=4 and r:match("^%a[%w_]*$")~=nil)
    elseif type(r)=="number" then
      if prevKeyN then prevKeyN=false; return mk(r,tostring(r)) end
      prevKeyN=false
    end
  end
  return nil
end
env.print = function(...) logb("PRINT",...) end
env.warn  = function(...) logb("WARN",...) end
env.getgenv = ES.getgenv
env.loadstring = function(s,...) local f=loadstring(s,...); if f then setfenv(f,env) end return f end
local RI = realenv.Instance
env.Instance = setmetatable({}, {__index=function(_,k) if k=="new" then return function(c,...) logb("Instance.new",c); return RI.new(c,...) end end return RI[k] end})

-- run the payload: it connects Players.PlayerAdded to its REAL handler
local f = loadstring(loaderSrc); setfenv(f, env)
local ok, err = pcall(f, payload)
logb("SETUP", ok, err)
local setupLen = #stream

-- now WAIT for the natural PlayerAdded. Use Test -> Start (1 player) so the client
-- joins AFTER this server script has connected the handler. We poll up to ~40s and
-- stop once handler activity (stream growth) settles.
inHandler = true
handlerMark = #stream
local Players = game:GetService("Players")
logb("WAITING", "players now:", #Players:GetPlayers())
local waited, lastLen, stable = 0, #stream, 0
while waited < 40 do
  task.wait(1); waited = waited + 1
  local n = #stream
  if #Players:GetPlayers() > 0 then logb("PLAYER_PRESENT", "t="..waited) end
  if n > lastLen then lastLen = n; stable = 0
  elseif n > handlerMark then stable = stable + 1; if stable >= 3 then break end end
end
logb("WAIT_DONE", "waited="..waited.."s")

local out = {}
out[#out+1]="== obf2 PLAY-MODE HANDLER TRACE =="
out[#out+1]="setup ok: "..tostring(ok).."  err: "..tostring(err)
out[#out+1]="setup stream: "..setupLen.."   handler stream: "..(#stream-handlerMark)
out[#out+1]="arithmetic ops in handler: "..#ops
out[#out+1]="---- ARITHMETIC OPS (handler) ----"
for _,o in ipairs(ops) do out[#out+1]=o end
out[#out+1]="---- BEHAVIOR ----"
for _,l in ipairs(behavior) do out[#out+1]=l end
out[#out+1]="---- HANDLER STREAM ----"
for i=handlerMark+1,#stream do out[#out+1]=stream[i] end
pcall(function() HttpService:PostAsync(BASE.."result_handler", table.concat(out,"\n")) end)
print("== PLAY TRACE DONE ==  handler stream:", #stream-handlerMark, " ops:", #ops)
for i=1,#ops do print(ops[i]) end
