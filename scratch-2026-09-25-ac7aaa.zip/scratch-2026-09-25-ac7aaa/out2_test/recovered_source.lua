-- recovered by unobf.py smart_lift  (heuristic reconstruction from the
-- execution trace; local names auto-generated; verify property VALUES).

local v_players = game:GetService("Players")

v_players.PlayerAdded:Connect(function(player)
    player.CharacterAdded:Connect(function(character)
        task.wait(1)
        local count = 0
        for _, part in ipairs(character:GetChildren()) do
            if part:IsA("BasePart") then
                part.CanCollide = false  -- VALUE not in trace; confirm (obf2/3 used false)
                count = count + 1
            end
        end
        print(player.Name .. " parts: " .. tostring(count))
    end)
end)
