--!nocheck
-- studio_event_trace.lua
-- Captures the per-frame logic inside the payload's workspace.Changed handlers.
--
-- HOW TO RUN (you run it; it uses HttpService, which is server-only in Play):
--   1. python unobf.py "25ms_obf (1).lua" out --serve      (serves loader_sllog.lua + payload.bin on :8799)
--      (loader_sllog.lua is the resolver-logging loader; if you only have loader.lua,
--       make it by replacing, in loader.lua, exactly:
--         local function Sl(JV)if JV<0 then JV=-JV-gc end;return QT(gH[JV])end;
--       with:
--         local function Sl(JV)if JV<0 then JV=-JV-gc end;local _r=QT(gH[JV]);__SLLOG(_r);return _r end;
--       and save as loader_sllog.lua in the served folder.)
--   2. Press Play in Studio.
--   3. Open the command bar, switch it to the SERVER context, paste this whole file, Enter.
--   4. Read the printed "HANDLER STREAM" — that is the per-frame logic's constant stream.
--   5. Stop Play (discards everything; no leaks).

local BASE = "http://127.0.0.1:8799/"
local HttpService = game:GetService("HttpService")
local loaderSrc = HttpService:GetAsync(BASE .. "loader_sllog.lua")
local payload   = HttpService:GetAsync(BASE .. "payload.bin")
local realenv = getfenv()

local genv = {}
local ES = {
    identifyexecutor=function() return "Synapse X","2.0" end, getexecutorname=function() return "Synapse X" end,
    getgenv=function() return genv end, getrenv=function() return realenv end, getreg=function() return {} end, getgc=function() return {} end,
    getrawmetatable=function(o) local ok,m=pcall(getmetatable,o); return ok and m or nil end, setrawmetatable=function(o) return o end,
    setreadonly=function() end, isreadonly=function() return false end, make_writeable=function() end, make_readonly=function() end,
    hookfunction=function(a) return a end, replaceclosure=function(a) return a end, hookmetamethod=function() return function() end end,
    newcclosure=function(f) return f end, clonefunction=function(f) return f end, checkcaller=function() return false end,
    islclosure=function() return true end, iscclosure=function() return false end, getnamecallmethod=function() return "" end, setnamecallmethod=function() end,
    getcallingscript=function() return nil end, getscriptclosure=function() return function() end end, getscripthash=function() return "" end,
    request=function() return {StatusCode=200,Body="",Success=true} end, getconnections=function() return {} end,
    getinstances=function() return {} end, getnilinstances=function() return {} end, cloneref=function(x) return x end,
    compareinstances=function(a,b) return a==b end, setclipboard=function() end, fireclickdetector=function() end,
    firetouchinterest=function() end, firesignal=function() end, isnetworkowner=function() return true end,
}

local part = workspace:FindFirstChild("part") or Instance.new("Part")
part.Name = "part"; part.Anchored = true; part.Parent = workspace

local S = {}
local capWait = true          -- cap waits during setup so the gauntlet can't hang
local env = setmetatable({}, { __index = function(_, k) local rv=realenv[k]; if rv~=nil then return rv end return ES[k] end })
env.__SLLOG = function(r) local n=#S; if n<400000 then if type(r)=="string" then S[n+1]=r elseif type(r)=="number" then S[n+1]="#"..tostring(r) end end end
env.print = function() end; env.warn = function() end
env.loadstring = function(src,...) local f=loadstring(src,...); if f then setfenv(f,env) end return f end
env.getgenv = ES.getgenv
local RI = realenv.Instance
env.Instance = setmetatable({}, { __index=function(_,k) if k=="new" then return function(...) return RI.new(...) end end return RI[k] end })
local rtask = realenv.task; local wN=0
env.wait = function(...) if capWait then wN=wN+1; if wN>2 then error("WAIT_BUDGET") end return 0 end return rtask.wait(...) end
env.task = setmetatable({}, { __index=function(_,k)
    if k=="wait" then return env.wait end
    if k=="spawn" or k=="defer" or k=="delay" then return rtask[k] end   -- allow real threads now
    return rtask[k]
end })

local f = loadstring(loaderSrc); setfenv(f, env)
local ok, err = pcall(f, payload)
local mark = #S                          -- boundary: after this = handler activity
capWait = false                          -- real waits from here

-- fire the Changed handlers by mutating workspace.part over several frames
for i = 1, 20 do
    part.Size = Vector3.new(4 + i, 1 + i%3, 2 + i)
    part.CFrame = CFrame.new(i, i*2, i*3)
    part.Transparency = (i % 10) / 10
    part.Color = Color3.new((i%5)/5, (i%7)/7, (i%3)/3)
    rtask.wait()
end

local handler = {}
for i = mark+1, #S do handler[#handler+1] = S[i] end
local body = table.concat(handler, "\n")
pcall(function() HttpService:PostAsync(BASE .. "handlers", body) end)   -- saved as handlers.txt by --serve

print("== EVENT TRACE ==")
print("setup ok:", ok, err)
print("setup stream len:", mark, " handler stream len:", #handler)
print("---- HANDLER STREAM (first 300 tokens) ----")
print(table.concat(handler, " ", 1, math.min(300, #handler)))
