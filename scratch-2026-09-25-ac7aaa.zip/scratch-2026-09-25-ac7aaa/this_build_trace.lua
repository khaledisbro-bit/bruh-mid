--!nocheck
-- this_build_trace.lua  --  Layer-2 trace for THIS build (resolver uA / decoder eU / table Gt).
-- HOW TO RUN:
--   1) Make sure the local server is up (Claude runs it):  http://127.0.0.1:8799/
--   2) In Roblox Studio: open the Command Bar (View -> Command Bar).
--   3) Paste this WHOLE file, press Enter.
--   4) It prints a summary AND posts full results back to the server (result.txt).
-- Nothing is parented/saved to your place; it only reads + logs.

local BASE = "http://127.0.0.1:8799/"
local HttpService = game:GetService("HttpService")

local loaderSrc = HttpService:GetAsync(BASE .. "loader_capture.lua")
local payload   = HttpService:GetAsync(BASE .. "payload.bin")

local realenv = getfenv()
local genv = {}

-- executor-simulator stubs the 2023 VM's anti-tamper gauntlet expects (Studio lacks these)
local ES = {
    identifyexecutor=function() return "Synapse X","2.0" end, getexecutorname=function() return "Synapse X" end,
    getgenv=function() return genv end, getrenv=function() return realenv end, getreg=function() return {} end, getgc=function() return {} end,
    getrawmetatable=function(o) local ok,m=pcall(getmetatable,o); return ok and m or nil end, setrawmetatable=function(o) return o end,
    setreadonly=function() end, isreadonly=function() return false end, make_writeable=function() end, make_readonly=function() end,
    hookfunction=function(a) return a end, replaceclosure=function(a) return a end, hookmetamethod=function() return function() end end,
    newcclosure=function(f) return f end, clonefunction=function(f) return f end, checkcaller=function() return true end,
    islclosure=function() return true end, iscclosure=function() return false end, getnamecallmethod=function() return "" end, setnamecallmethod=function() end,
    getcallingscript=function() return nil end, getscriptclosure=function() return function() end end, getscripthash=function() return "" end,
    request=function() return {StatusCode=200,Body="",Success=true} end, getconnections=function() return {} end,
    getinstances=function() return {} end, getnilinstances=function() return {} end, cloneref=function(x) return x end,
    compareinstances=function(a,b) return a==b end, setclipboard=function() end, fireclickdetector=function() end,
    firetouchinterest=function() end, firesignal=function() end, isnetworkowner=function() return true end,
    getthreadidentity=function() return 8 end, setthreadidentity=function() end, checkclosure=function() return true end,
    isourclosure=function() return true end, isexecutorclosure=function() return true end,
}

-- some builds index workspace.part unwrapped; make sure it exists
local part = workspace:FindFirstChild("part") or Instance.new("Part")
part.Name="part"; part.Anchored=true; part.Parent=workspace

-- capture hook injected right after the resolver (see loader_capture.lua)
local cap = {}
local behavior = {}
local function logb(kind, ...)
    local p={}; for i=1,select("#",...) do p[i]=tostring((select(i,...))) end
    behavior[#behavior+1] = kind..": "..table.concat(p," | ")
end

local env = setmetatable({}, { __index=function(_,k)
    local rv = realenv[k]; if rv~=nil then return rv end
    return ES[k]
end })
env.__CAP = function(dec, tbl) cap.eU = dec; cap.Gt = tbl end

-- ==== TAINT TRACKER: wrap payload numeric constants to log every arithmetic op ====
local track = false            -- turns on when the payload region starts ("Alpha")
local TRIGGER = "Alpha"        -- first constant unique to the real program
local ops = {}                 -- captured arithmetic operations, in order
local PMT = {}                 -- proxy metatable
local function uw(x) if type(x)=="table" and rawget(x,"__taint") then return x.__v end return x end
local function pv(x) if type(x)=="table" and rawget(x,"__taint") then return x.__e end return tostring(x) end
local function mk(v, e) return setmetatable({__taint=true, __v=v, __e=e}, PMT) end
local function binop(sym, name)
    return function(a, b)
        local av, bv = uw(a), uw(b)
        local res = ({ADD=function()return av+bv end, SUB=function()return av-bv end,
            MUL=function()return av*bv end, DIV=function()return av/bv end,
            MOD=function()return av%bv end, POW=function()return av^bv end})[name]()
        ops[#ops+1] = ("%s(%s , %s) = %s"):format(name, pv(a), pv(b), tostring(res))
        return mk(res, "("..pv(a)..sym..pv(b)..")")
    end
end
PMT.__add=binop("+","ADD"); PMT.__sub=binop("-","SUB"); PMT.__mul=binop("*","MUL")
PMT.__div=binop("/","DIV"); PMT.__mod=binop("%","MOD"); PMT.__pow=binop("^","POW")
PMT.__unm=function(a) ops[#ops+1]="UNM("..pv(a)..")"; return mk(-uw(a),"(-"..pv(a)..")") end
PMT.__eq=function(a,b) return uw(a)==uw(b) end
PMT.__lt=function(a,b) return uw(a)<uw(b) end
PMT.__le=function(a,b) return uw(a)<=uw(b) end
PMT.__concat=function(a,b) return pv(a)..pv(b) end
PMT.__tostring=function(a) return tostring(uw(a)) end

-- ordered resolution stream (as before) + taint injection
local stream = {}
env.__SL = function(r, idx)
    local n=#stream
    if n<500000 then
        if type(r)=="string" then stream[n+1]="S:"..r
        elseif type(r)=="number" then stream[n+1]="N:"..tostring(r)
        elseif type(r)=="boolean" then stream[n+1]="B:"..tostring(r)
        else stream[n+1]="?:"..type(r) end
    end
    if type(r)=="string" and r==TRIGGER then track=true end
    -- once inside the payload, wrap numeric constants so arithmetic is logged
    if track and type(r)=="number" then
        return mk(r, tostring(r))   -- REPLACE the constant with a tracked proxy
    end
    return nil
end
env.print = function(...) logb("PRINT", ...) end
env.warn  = function(...) logb("WARN", ...) end
env.getgenv = ES.getgenv
env.loadstring = function(src,...) local f=loadstring(src,...); if f then setfenv(f,env) end return f end
local RI = realenv.Instance
env.Instance = setmetatable({}, { __index=function(_,k)
    if k=="new" then return function(cls,...) logb("Instance.new",cls); return RI.new(cls,...) end end
    return RI[k]
end })
-- cap waits so the gauntlet can't hang the command bar
local rtask = realenv.task; local wN=0
env.wait = function(...) wN=wN+1; if wN>3 then error("WAIT_BUDGET") end; return 0 end
env.task = setmetatable({}, { __index=function(_,k)
    if k=="wait" then return env.wait end
    return rtask[k]
end })

-- run the loader (self-decodes constants; gauntlet may error -- that's fine, we captured eU/Gt)
local f = loadstring(loaderSrc); setfenv(f, env)
local ok, err = pcall(f, payload)

-- decrypt every constant now that we hold the real decoder + table
local strings, numbers = {}, 0
if cap.eU and cap.Gt then
    for i=1,#cap.Gt do
        local okc, v = pcall(cap.eU, cap.Gt[i])
        if okc then
            if type(v)=="string" then
                -- keep only mostly-printable strings (drops junk/decoy tokens)
                local printable=true
                for j=1,#v do local b=v:byte(j); if b<9 or (b>13 and b<32) or b>126 then printable=false break end end
                if printable and #v>0 then strings[#strings+1]=v end
            elseif type(v)=="number" then numbers=numbers+1 end
        end
    end
end

-- assemble report
local out = {}
out[#out+1]="== LAYER 2 TRACE (this build) =="
out[#out+1]="run ok: "..tostring(ok).."  err: "..tostring(err)
out[#out+1]="captured decoder+table: "..tostring(cap.eU~=nil and cap.Gt~=nil)
out[#out+1]="constants: "..#strings.." printable strings, "..numbers.." numbers"
out[#out+1]="behavior log lines: "..#behavior
out[#out+1]="resolution stream length: "..#stream
out[#out+1]="arithmetic ops captured: "..#ops
out[#out+1]="---- ARITHMETIC OPS (payload, execution order) ----"
for _,o in ipairs(ops) do out[#out+1]=o end
out[#out+1]="---- STRING CONSTANTS ----"
for _,s in ipairs(strings) do out[#out+1]=s end
out[#out+1]="---- BEHAVIOR LOG ----"
for _,l in ipairs(behavior) do out[#out+1]=l end
out[#out+1]="---- RESOLUTION STREAM (execution order) ----"
for _,r in ipairs(stream) do out[#out+1]=r end
local body = table.concat(out,"\n")

pcall(function() HttpService:PostAsync(BASE.."result", body) end)

print("== TRACE DONE ==")
print("ok:",ok," captured:",cap.eU~=nil and cap.Gt~=nil)
print("strings:",#strings," numbers:",numbers," behavior:",#behavior," stream:",#stream," ARITH OPS:",#ops)
print("---- arithmetic ops (the real math) ----")
for i=1,math.min(20,#ops) do print(ops[i]) end
print("(full results posted to the server as result.txt)")
print("---- first 40 string constants ----")
for i=1,math.min(40,#strings) do print(i, strings[i]) end
