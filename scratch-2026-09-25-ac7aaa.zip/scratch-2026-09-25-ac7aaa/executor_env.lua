--!nocheck
-- executor_env.lua
-- A UNC-style executor-environment SIMULATOR for running/analysing scripts
-- inside Roblox Studio (which lacks executor globals). Analysis / deobfuscation
-- use: apply this env to a chunk with setfenv so its executor calls resolve to
-- these implementations, while real Roblox globals (game, workspace, datatypes)
-- fall through untouched.
--
-- UNC reference: github.com/unified-naming-convention/NamingStandard
--
-- USAGE (in Studio; use Play->Client if the target script needs LocalPlayer):
--   local makeEnv = <this module's return>
--   local env, ctx = makeEnv()                 -- ctx exposes logs/fake FS/genv
--   local f = loadstring(SOURCE)
--   setfenv(f, env)
--   f(...)
--   -- inspect ctx.log, ctx.fs, ctx.drawings, ctx.genv afterwards
--
-- Returns: function makeEnv(realenv?) -> (env, ctx)

local function makeEnv(realenv)
    realenv = realenv or getfenv(2)
    local ctx = {
        genv = {}, fs = {}, drawings = {}, sockets = {}, log = {},
        hooks = {}, scriptable = {},
    }
    local function logc(cat, ...)
        local p = {}
        for i = 1, select("#", ...) do p[i] = tostring((select(i, ...))) end
        ctx.log[#ctx.log + 1] = cat .. ": " .. table.concat(p, " | ")
    end

    -- ---- base64 (real) ----
    local B64 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"
    local function b64enc(data)
        return ((data:gsub(".", function(x)
            local r, b = "", x:byte()
            for i = 8, 1, -1 do r = r .. (b % 2^i - b % 2^(i-1) > 0 and "1" or "0") end
            return r
        end) .. "0000"):gsub("%d%d%d?%d?%d?%d?", function(x)
            if #x < 6 then return "" end
            local c = 0
            for i = 1, 6 do c = c + (x:sub(i, i) == "1" and 2^(6-i) or 0) end
            return B64:sub(c + 1, c + 1)
        end) .. ({ "", "==", "=" })[#data % 3 + 1])
    end
    local function b64dec(data)
        data = data:gsub("[^" .. B64 .. "=]", "")
        return (data:gsub(".", function(x)
            if x == "=" then return "" end
            local r, f = "", (B64:find(x) - 1)
            for i = 6, 1, -1 do r = r .. (f % 2^i - f % 2^(i-1) > 0 and "1" or "0") end
            return r
        end):gsub("%d%d%d?%d?%d?%d?%d?%d?", function(x)
            if #x ~= 8 then return "" end
            local c = 0
            for i = 1, 8 do c = c + (x:sub(i, i) == "1" and 2^(8-i) or 0) end
            return string.char(c)
        end))
    end

    -- ---- closure/identity helpers ----
    local function newcclosure(f) return f end
    local function clonefunction(f) return function(...) return f(...) end end

    -- ---- the UNC surface ----
    local U = {}
    -- Scripts / env
    U.getgenv = function() return ctx.genv end
    U.getrenv = function() return realenv end
    U.getgc = function() return {} end
    U.getloadedmodules = function() return {} end
    U.getrunningscripts = function() return {} end
    U.getscripts = function() return {} end
    U.getsenv = function() return {} end
    U.getscriptbytecode = function() return "" end
    U.getscripthash = function() return "" end
    U.getthreadidentity = function() return 8 end
    U.setthreadidentity = function() end
    U.getidentity = U.getthreadidentity
    -- Core
    U.cloneref = function(x) return x end
    U.compareinstances = function(a, b) return a == b end
    U.checkcaller = function() return true end
    U.clonefunction = clonefunction
    U.getcallingscript = function() return nil end
    U.getscriptclosure = function() return function() end end
    U.getscriptfunction = U.getscriptclosure
    U.newcclosure = newcclosure
    U.iscclosure = function() return false end
    U.islclosure = function() return true end
    U.isexecutorclosure = function() return true end
    U.checkclosure = U.isexecutorclosure
    U.isourclosure = U.isexecutorclosure
    U.hookfunction = function(target, hook) ctx.hooks[#ctx.hooks+1] = hook; return target end
    U.replaceclosure = U.hookfunction
    U.loadstring = function(src, name)
        local f, e = loadstring(src, name)
        if f then setfenv(f, getfenv(2)) end
        return f, e
    end
    -- Metatable
    U.getrawmetatable = function(o) local ok, m = pcall(getmetatable, o); return ok and m or nil end
    U.setrawmetatable = function(o, mt) pcall(setmetatable, o, mt); return o end
    U.setreadonly = function() end
    U.isreadonly = function() return false end
    U.make_writeable = function() end
    U.make_readonly = function() end
    U.hookmetamethod = function(_, _, hook) return hook or function() end end
    U.getnamecallmethod = function() return ctx.namecall or "" end
    U.setnamecallmethod = function(m) ctx.namecall = m end
    -- Instances
    U.fireclickdetector = function() end
    U.firetouchinterest = function() end
    U.fireproximityprompt = function() end
    U.getcallbackvalue = function() return nil end
    U.getconnections = function() return {} end
    U.getcustomasset = function() return "" end
    U.gethiddenproperty = function(inst, prop) local ok, v = pcall(function() return inst[prop] end); return ok and v or nil, false end
    U.sethiddenproperty = function(inst, prop, val) local ok = pcall(function() inst[prop] = val end); return ok end
    U.gethui = function()
        local ok, cg = pcall(function() return game:GetService("CoreGui") end)
        if ok and cg then return cg end
        return game:GetService("Players")
    end
    U.getinstances = function() local t = {}; for _, d in ipairs(game:GetDescendants()) do t[#t+1] = d end; return t end
    U.getnilinstances = function() return {} end
    U.isscriptable = function(_, prop) return ctx.scriptable[prop] ~= false end
    U.setscriptable = function(_, prop, v) local o = ctx.scriptable[prop]; ctx.scriptable[prop] = v; return o end
    U.setrbxclipboard = function() return true end
    U.isnetworkowner = function() return true end
    -- Filesystem (in-memory)
    U.readfile = function(p) return ctx.fs[p] end
    U.writefile = function(p, d) ctx.fs[p] = d end
    U.appendfile = function(p, d) ctx.fs[p] = (ctx.fs[p] or "") .. d end
    U.isfile = function(p) return ctx.fs[p] ~= nil end
    U.isfolder = function() return true end
    U.makefolder = function() end
    U.delfolder = function() end
    U.delfile = function(p) ctx.fs[p] = nil end
    U.listfiles = function() local t = {}; for k in pairs(ctx.fs) do t[#t+1] = k end; return t end
    U.loadfile = function(p) if ctx.fs[p] then return loadstring(ctx.fs[p]) end return nil, "no file" end
    U.dofile = function(p) local f = U.loadfile(p); if f then return f() end end
    -- Crypt
    U.crypt = {
        base64encode = b64enc, base64decode = b64dec,
        base64 = { encode = b64enc, decode = b64dec },
        encode = b64enc, decode = b64dec,
        encrypt = function(d) return b64enc(d) end,
        decrypt = function(d) return b64dec(d) end,
        generatebytes = function(n) local t = {}; for i = 1, (n or 16) do t[i] = string.char(math.random(0, 255)) end; return b64enc(table.concat(t)) end,
        generatekey = function() local t = {}; for i = 1, 32 do t[i] = string.char(math.random(0, 255)) end; return b64enc(table.concat(t)) end,
        hash = function(d) local h = 0; for i = 1, #d do h = (h * 31 + d:byte(i)) % 2^32 end; return string.format("%08x", h) end,
    }
    U.base64 = U.crypt.base64
    U.base64encode = b64enc; U.base64decode = b64dec
    U.lz4compress = function(d) return d end
    U.lz4decompress = function(d) return d end
    -- Debug extensions (fall through to real debug for getinfo)
    local realdebug = realenv.debug or debug
    U.debug = setmetatable({
        getconstant = function() return nil end,
        getconstants = function() return {} end,
        getinfo = function(...) return realdebug.info and realdebug.info(...) or {} end,
        getproto = function() return function() end end,
        getprotos = function() return {} end,
        getstack = function() return {} end,
        getupvalue = function() return nil end,
        getupvalues = function() return {} end,
        setconstant = function() end,
        setstack = function() end,
        setupvalue = function() end,
    }, { __index = realdebug })
    -- Console
    U.rconsoleprint = function(...) logc("rconsole", ...) end
    U.rconsoleinfo = U.rconsoleprint; U.rconsolewarn = U.rconsoleprint; U.rconsoleerr = U.rconsoleprint
    U.rconsoleclear = function() end
    U.rconsolecreate = function() end
    U.rconsoledestroy = function() end
    U.rconsoleinput = function() return "" end
    U.rconsolesettitle = function() end
    U.rconsolename = U.rconsolesettitle
    U.printconsole = U.rconsoleprint
    -- Input (no-op, logged)
    for _, n in ipairs({ "mouse1click","mouse1press","mouse1release","mouse2click","mouse2press",
        "mouse2release","mousemoveabs","mousemoverel","mousescroll","keypress","keyrelease" }) do
        U[n] = function(...) logc("input." .. n, ...) end
    end
    U.isrbxactive = function() return true end
    U.isgameactive = U.isrbxactive
    -- Misc
    U.identifyexecutor = function() return "Synapse X", "2.0" end
    U.getexecutorname = function() return "Synapse X" end
    U.messagebox = function(...) logc("messagebox", ...); return 1 end
    U.queue_on_teleport = function() end
    U.setclipboard = function(v) ctx.clipboard = v end
    U.toclipboard = U.setclipboard
    U.setfpscap = function() end
    U.request = function(o) logc("request", type(o) == "table" and o.Url or o); return { StatusCode = 200, Success = true, Body = "", Headers = {} } end
    U.http = { request = U.request }
    U.http_request = U.request
    -- Drawing (records objects instead of rendering)
    local DrawingMT = { __index = function(t, k) return rawget(t, "_p")[k] end,
        __newindex = function(t, k, v) rawget(t, "_p")[k] = v end }
    U.Drawing = {
        Fonts = { UI = 0, System = 1, Plex = 2, Monospace = 3 },
        new = function(class)
            local obj = setmetatable({ _p = { __class = class, Visible = false, ZIndex = 0,
                Transparency = 1, Color = Color3.new(1,1,1), Remove = false } }, DrawingMT)
            rawget(obj, "_p").Remove = function() end
            rawget(obj, "_p").Destroy = rawget(obj, "_p").Remove
            ctx.drawings[#ctx.drawings + 1] = obj
            return obj
        end,
    }
    U.isrenderobj = function(o) return getmetatable(o) == DrawingMT end
    U.getrenderproperty = function(o, p) return o[p] end
    U.setrenderproperty = function(o, p, v) o[p] = v end
    U.cleardrawcache = function() ctx.drawings = {} end
    -- Cache
    U.cache = {
        invalidate = function() end, iscached = function() return true end,
        replace = function() end,
    }
    U.invalidatecache = U.cache.invalidate
    -- WebSocket
    U.WebSocket = { connect = function(url)
        local sock = { Send = function() end, Close = function() end,
            OnMessage = { Connect = function() return { Disconnect = function() end } end },
            OnClose = { Connect = function() return { Disconnect = function() end } end } }
        ctx.sockets[#ctx.sockets + 1] = { url = url, sock = sock }
        return sock
    end }
    U.syn = { request = U.request, crypt = U.crypt, protect_gui = function() end,
        unprotect_gui = function() end, queue_on_teleport = U.queue_on_teleport,
        write_clipboard = U.setclipboard }
    U.fluxus = { request = U.request }

    -- ---- assemble env: U wins, else real global ----
    local env = setmetatable({}, { __index = function(_, k)
        local u = U[k]
        if u ~= nil then return u end
        return realenv[k]
    end })
    -- getgenv/getfenv consistency: make getfenv() inside return this env
    return env, ctx
end

return makeEnv
