name: build

on:
  push:
    branches:
      - 'master'
    paths-ignore:
      - 'docs/**'
      - 'papers/**'
      - 'rfcs/**'
      - '*.md'
  pull_request:
    paths-ignore:
      - 'docs/**'
      - 'papers/**'
      - 'rfcs/**'
      - '*.md'

jobs:
  unix:
    strategy:
      matrix:
        os: [{name: ubuntu, version: ubuntu-latest}, {name: macos, version: macos-latest}, {name: macos-arm, version: macos-14}]
        compiler:
          - name: Clang
            cc: clang
            cxx: clang++
          - name: GCC
            cc: gcc
            cxx: g++
    name: ${{matrix.os.name}} with ${{matrix.compiler.name}}
    runs-on: ${{matrix.os.version}}
    steps:
    - uses: actions/checkout@v1
    - name: work around ASLR+ASAN compatibility
      run: sudo sysctl -w vm.mmap_rnd_bits=28
      if: matrix.os.name == 'ubuntu'
    - name: make tests
      run: |
        CC=${{matrix.compiler.cc}} CXX=${{matrix.compiler.cxx}} make -j2 config=sanitize werror=1 native=1 luau-tests
    - name: run tests
      run: |
        ./luau-tests
        ./luau-tests --fflags=true
        ./luau-tests --fflags=DebugLuauForceOldSolver
        ./luau-tests --fflags=DebugLuauForceOldSolver,true
    - name: run extra conformance tests
      run: |
        ./luau-tests -ts=Conformance -O2
        ./luau-tests -ts=Conformance -O2 --fflags=true
        ./luau-tests -ts=Conformance --codegen
        ./luau-tests -ts=Conformance --codegen --fflags=true
        ./luau-tests -ts=Conformance --codegen -O2
        ./luau-tests -ts=Conformance --codegen -O2 --fflags=true
        ./luau-tests -ts=Conformance --codegen -O2 --fflags=true,DebugCodegenChaosA64=true
        ./luau-tests -ts=Conformance --codegen -O2 --fflags=true,DebugCodegenLimitRegs=true
    - name: make cli
      run: |
         make -j2 config=sanitize werror=1 luau luau-analyze luau-compile # match config with tests to improve build time
         ./luau tests/conformance/assert.luau
         ./luau-analyze tests/conformance/assert.luau
         ./luau-compile tests/conformance/assert.luau

  windows:
    runs-on: windows-latest
    strategy:
      matrix:
        arch: [Win32, x64]
    steps:
    - uses: actions/checkout@v1
    - name: cmake configure
      run: cmake . -A ${{matrix.arch}} -DLUAU_WERROR=ON
    - name: cmake build
      run: cmake --build . --target Luau.UnitTest Luau.Conformance --config Debug
    - name: run tests
      shell: bash # necessary for fail-fast
      run: |
        Debug/Luau.UnitTest.exe
        Debug/Luau.Conformance.exe
        Debug/Luau.UnitTest.exe --fflags=true
        Debug/Luau.Conformance.exe --fflags=true
        Debug/Luau.UnitTest.exe --fflags=DebugLuauForceOldSolver
        Debug/Luau.UnitTest.exe --fflags=DebugLuauForceOldSolver,true
    - name: run extra conformance tests
      shell: bash # necessary for fail-fast
      run: |
        Debug/Luau.Conformance.exe -O2
        Debug/Luau.Conformance.exe -O2 --fflags=true
        Debug/Luau.Conformance.exe --codegen
        Debug/Luau.Conformance.exe --codegen --fflags=true
        Debug/Luau.Conformance.exe --codegen -O2
        Debug/Luau.Conformance.exe --codegen -O2 --fflags=true
        Debug/Luau.Conformance.exe --codegen -O2 --fflags=true,DebugCodegenLimitRegs=true
    - name: cmake cli
      shell: bash # necessary for fail-fast
      run: |
        cmake --build . --target Luau.Repl.CLI Luau.Analyze.CLI Luau.Compile.CLI --config Debug # match config with tests to improve build time
        Debug/luau tests/conformance/assert.luau
        Debug/luau-analyze tests/conformance/assert.luau
        Debug/luau-compile tests/conformance/assert.luau

  configurations:
    strategy:
      matrix:
        config:
          - name: LongJmp
            flags: "-DLUA_USE_LONGJMP=1"
            codegen: true
          - name: Vector4
            flags: "-DLUA_VECTOR_SIZE=4"
            codegen: false
          - name: VectorDouble
            flags: "-DLUA_VECTOR_DOUBLE=1"
            codegen: false
    name: run extra configuration (${{matrix.config.name}})
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v1
    - name: cmake configure
      run: cmake . -B build -DCMAKE_BUILD_TYPE=Debug -DLUAU_WERROR=ON -DCMAKE_CXX_FLAGS="${{matrix.config.flags}}" -DCMAKE_C_FLAGS="${{matrix.config.flags}}"
    - name: cmake build
      run: cmake --build build --target Luau.Conformance --config Debug -j2
    - name: run tests
      run: |
        build/Luau.Conformance
        build/Luau.Conformance --fflags=true
        build/Luau.Conformance -O2
        build/Luau.Conformance -O2 --fflags=true
    - name: run codegen tests
      if: matrix.config.codegen
      run: |
        build/Luau.Conformance --codegen --fflags=true
        build/Luau.Conformance --codegen -O2 --fflags=true

  coverage:
    runs-on: ubuntu-22.04
    steps:
    - uses: actions/checkout@v2
    - name: install
      run: |
        sudo apt install llvm
    - name: make coverage
      run: |
        CXX=clang++ make -j2 config=coverage native=1 coverage
    - name: upload coverage
      uses: codecov/codecov-action@v3
      with:
        files: ./coverage.info
        token: ${{ secrets.CODECOV_TOKEN }}

  web:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v1
    - uses: actions/checkout@v2
      with:
        repository: emscripten-core/emsdk
        path: emsdk
    - name: emsdk install
      run: |
        cd emsdk
        ./emsdk install latest
        ./emsdk activate latest
    - name: make
      run: |
        source emsdk/emsdk_env.sh
        emcmake cmake . -DLUAU_BUILD_WEB=ON -DCMAKE_BUILD_TYPE=Release
        make -j2 Luau.Web
