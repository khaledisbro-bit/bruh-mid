name: new-release

on:
  workflow_dispatch:
    inputs:
      version:
        required: true
        description: Release version including 0.

permissions:
  contents: write

jobs:
  create-release:
    runs-on: ubuntu-latest
    outputs:
      upload_url: ${{ steps.create_release.outputs.upload_url }}
    steps:
      - name: validate version format
        run: |
          if [[ ! "${{ github.event.inputs.version }}" =~ ^0\.[0-9]{3,}$ ]]; then
            echo "Error: Version must be in the format 0.XYZ"
            exit 1
          fi
      - name: create release
        id: create_release
        uses: actions/create-release@v1
        env:
          GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
        with:
          tag_name: ${{ github.event.inputs.version }}
          release_name: ${{ github.event.inputs.version }}
          draft: true

  build:
    needs: ["create-release"]
    strategy:
      matrix: # not using ubuntu-latest to improve compatibility
        os: [{name: ubuntu, version: ubuntu-22.04}, {name: macos, version: macos-latest}, {name: windows, version: windows-latest}]
    name: ${{matrix.os.name}}
    runs-on: ${{matrix.os.version}}
    steps:
    - uses: actions/checkout@v1
    - name: configure
      run: cmake . -DCMAKE_BUILD_TYPE=Release
    - name: build
      run: cmake --build . --target Luau.Repl.CLI Luau.Analyze.CLI Luau.Compile.CLI Luau.Ast.CLI --config Release -j 2
    - name: pack
      if: matrix.os.name != 'windows'
      run: zip luau-${{matrix.os.name}}.zip luau*
    - name: pack
      if: matrix.os.name == 'windows'
      run: 7z a luau-${{matrix.os.name}}.zip .\Release\luau*.exe
    - uses: actions/upload-release-asset@v1
      env:
        GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
      with:
        upload_url: ${{ needs.create-release.outputs.upload_url }}
        asset_path: luau-${{matrix.os.name}}.zip
        asset_name: luau-${{matrix.os.name}}.zip
        asset_content_type: application/octet-stream

  web:
    needs: ["create-release"]
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v1
    - uses: actions/checkout@v2
      with:
        repository: emscripten-core/emsdk
        path: emsdk
    - name: emsdk install
      run: |
        cd emsdk
        ./emsdk install latest
        ./emsdk activate latest
    - name: make
      run: |
        source emsdk/emsdk_env.sh
        emcmake cmake . -DLUAU_BUILD_WEB=ON -DCMAKE_BUILD_TYPE=Release
        make -j2 Luau.Web
    - uses: actions/upload-release-asset@v1
      env:
        GITHUB_TOKEN: ${{ secrets.GITHUB_TOKEN }}
      with:
        upload_url: ${{ needs.create-release.outputs.upload_url }}
        asset_path: Luau.Web.js
        asset_name: Luau.Web.js
        asset_content_type: application/octet-stream
