{
    "version": 6,
    "configurePresets": [
        {
            "name": "fuzz",
            "displayName": "Fuzz",
            "description": "Configures required fuzzer settings.",
            "binaryDir": "build",
            "condition": {
                "type": "anyOf",
                "conditions": [
                    {
                        "type": "equals",
                        "lhs": "${hostSystemName}",
                        "rhs": "Darwin"
                    },
                    {
                        "type": "equals",
                        "lhs": "${hostSystemName}",
                        "rhs": "Linux"
                    }
                ]
            },
            "cacheVariables": {
                "CMAKE_OSX_ARCHITECTURES": "x86_64",
                "CMAKE_BUILD_TYPE": "Release",
                "CMAKE_CXX_STANDARD": "17",
                "CMAKE_CXX_EXTENSIONS": false
            },
            "warnings": {
                "dev": false
            }
        }
    ],
    "buildPresets": [
        {
            "name": "fuzz-proto",
            "displayName": "Protobuf Fuzzer",
            "description": "Builds the protobuf-based fuzzer and transpiler tools.",
            "configurePreset": "fuzz",
            "targets": [
                "Luau.Fuzz.Proto",
                "Luau.Fuzz.ProtoTest"
            ]
        }
    ]
}
