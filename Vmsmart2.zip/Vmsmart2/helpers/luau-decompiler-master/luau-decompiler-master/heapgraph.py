local A = require("./cyclic_mutation_a")
export local foo = "foo"
