/build/
/build[.-]*/
/out
/cmake/
/cmake[.-]*/
/coverage/
/.vs/
/.vscode/
/fuzz/luau.pb.*
/crash-*
/default.prof*
/fuzz-*
/luau
/luau-tests
/luau-analyze
/luau-bytecode
/luau-compile
__pycache__
.cache
.clangd

# Golden-test captured outputs for user debugging
*.output.tmp
