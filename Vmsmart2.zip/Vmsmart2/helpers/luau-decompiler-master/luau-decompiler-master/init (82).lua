return {"result from outer_dependency"}
