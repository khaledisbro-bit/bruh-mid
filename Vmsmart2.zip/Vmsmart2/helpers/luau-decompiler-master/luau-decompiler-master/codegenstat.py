return require("@otherdep")
