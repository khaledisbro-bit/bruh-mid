name: release

on:
  push:
    branches:
      - 'master'
    paths-ignore:
      - 'docs/**'
      - 'papers/**'
      - 'rfcs/**'
      - '*.md'

jobs:
  build:
    strategy:
      matrix: # not using ubuntu-latest to improve compatibility
        os: [{name: ubuntu, version: ubuntu-22.04}, {name: macos, version: macos-latest}, {name: windows, version: windows-latest}]
    name: ${{matrix.os.name}}
    runs-on: ${{matrix.os.version}}
    steps:
    - uses: actions/checkout@v1
    - name: configure
      run: cmake . -DCMAKE_BUILD_TYPE=Release
    - name: build
      run: cmake --build . --target Luau.Repl.CLI Luau.Analyze.CLI Luau.Compile.CLI --config Release -j 2
    - uses: actions/upload-artifact@v4
      if: matrix.os.name != 'windows'
      with:
        name: luau-${{matrix.os.name}}
        path: luau*
        overwrite: true
    - uses: actions/upload-artifact@v4
      if: matrix.os.name == 'windows'
      with:
        name: luau-${{matrix.os.name}}
        path: Release\luau*.exe
        overwrite: true
  web:
    runs-on: ubuntu-latest
    steps:
    - uses: actions/checkout@v1
    - uses: actions/checkout@v2
      with:
        repository: emscripten-core/emsdk
        path: emsdk
    - name: emsdk install
      run: |
        cd emsdk
        ./emsdk install latest
        ./emsdk activate latest
    - name: make
      run: |
        source emsdk/emsdk_env.sh
        emcmake cmake . -DLUAU_BUILD_WEB=ON -DCMAKE_BUILD_TYPE=Release
        make -j2 Luau.Web
    - uses: actions/upload-artifact@v4
      with:
        name: Luau.Web.js
        path: Luau.Web.js
        overwrite: true
